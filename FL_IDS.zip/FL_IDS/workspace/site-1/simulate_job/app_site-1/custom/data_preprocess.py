import logging
from collections import Counter
from datetime import datetime
from sklearn.metrics import confusion_matrix, classification_report

import torch
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
from typing import Dict

from nvflare.apis.shareable import Shareable
from nvflare.apis.dxo import DXO, DataKind
from nvflare.apis.fl_context import FLContext
from nvflare.app_common.aggregators.intime_accumulate_model_aggregator import InTimeAccumulateWeightedAggregator

from custom.unsw_nb15_model import IDS_MLP


class CustomAggregatorWithEval(InTimeAccumulateWeightedAggregator):
    def __init__(self, expected_data_kind: str = DataKind.WEIGHTS, aggregation_weights: Dict[str, float] = None):
        super().__init__(expected_data_kind=expected_data_kind, aggregation_weights=aggregation_weights)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        self.current_round = 0

    def load_test_data(self):
        """加载测试数据"""
        df = pd.read_csv(self.test_path)
        X = torch.tensor(df.drop(columns=["label"]).values, dtype=torch.float32)
        y = torch.tensor(df["label"].values, dtype=torch.long)
        loader = DataLoader(TensorDataset(X, y), batch_size=128, shuffle=False)
        return loader, X.shape[1]

    def evaluate_model(self, model, test_loader, round_num):
        """评估模型性能"""
        model.eval()
        correct = 0
        total = 0
        all_preds = []
        all_labels = []

        with torch.no_grad():
            for batch_x, batch_y in test_loader:
                batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                outputs = model(batch_x)
                _, predicted = torch.max(outputs, 1)
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(batch_y.cpu().numpy())
                correct += (predicted == batch_y).sum().item()
                total += batch_y.size(0)

        acc = correct / total

        pred_dist = Counter(all_preds)
        true_dist = Counter(all_labels)
        cm = confusion_matrix(all_labels, all_preds)
        report = classification_report(all_labels, all_preds)

        self.logger.info(f"\n🔥 ========== Round {round_num} Global Model Evaluation ==========")
        self.logger.info(f"✅ [SERVER] Global Model Accuracy: {acc * 100:.2f}%")
        self.logger.info(f"🔢 Predicted Label Distribution: {pred_dist}")
        self.logger.info(f"📊 True Label Distribution: {true_dist}")
        self.logger.info(f"📉 Confusion Matrix:\n{cm}")
        self.logger.info(f"📋 Classification Report:\n{report}")
        self.logger.info(f"🔥 ============================================================\n")

        return acc

def aggregate(self, fl_ctx: FLContext) -> Shareable:
        """聚合客户端结果并评估全局模型"""
        
        # 调用父类的聚合方法
        aggregated_shareable = super().aggregate(fl_ctx)
        
        # 从fl_ctx获取当前轮数
        current_round = fl_ctx.get_prop("current_round", self.current_round + 1)
        self.current_round = current_round
        
        if aggregated_shareable is None:
            self.logger.error(f"[Round {self.current_round}] ❌ Aggregation failed")
            return aggregated_shareable
        
        self.logger.info(f"[Round {self.current_round}] ✅ Model aggregation completed")
        self.logger.info(f"[Round {self.current_round}] 🔍 Shareable keys: {list(aggregated_shareable.keys())}")
        
        # 评估聚合后的模型
        try:
            # 检查shareable中的数据类型
            if DataKind.WEIGHTS in aggregated_shareable:
                dxo = DXO.from_shareable(aggregated_shareable)
                global_weights = dxo.data
                self.logger.info(f"[Round {self.current_round}] 📥 Successfully extracted weights from DXO")
            elif "DXO" in aggregated_shareable:
                # 直接从DXO键获取
                dxo_data = aggregated_shareable["DXO"]
                if isinstance(dxo_data, DXO):
                    global_weights = dxo_data.data
                    self.logger.info(f"[Round {self.current_round}] 📥 Successfully extracted weights from DXO key")
                else:
                    self.logger.warning(f"[Round {self.current_round}] ⚠️ DXO key exists but not DXO type: {type(dxo_data)}")
                    return aggregated_shareable
            elif "dxo" in aggregated_shareable:
                # 尝试从dxo键获取
                dxo_data = aggregated_shareable["dxo"]
                if isinstance(dxo_data, DXO):
                    global_weights = dxo_data.data
                    self.logger.info(f"[Round {self.current_round}] 📥 Successfully extracted weights from dxo key")
                else:
                    self.logger.warning(f"[Round {self.current_round}] ⚠️ dxo key exists but not DXO type: {type(dxo_data)}")
                    return aggregated_shareable
            else:
                # 打印所有可用的键用于调试
                available_keys = list(aggregated_shareable.keys())
                self.logger.warning(f"[Round {self.current_round}] ⚠️ No weights found. Available keys: {available_keys}")
                
                # 尝试查看第一个键的内容
                if available_keys:
                    first_key = available_keys[0]
                    first_value = aggregated_shareable[first_key]
                    self.logger.info(f"[Round {self.current_round}] 🔍 First key '{first_key}' type: {type(first_value)}")
                    
                    if isinstance(first_value, DXO):
                        global_weights = first_value.data
                        self.logger.info(f"[Round {self.current_round}] 📥 Successfully extracted weights from '{first_key}'")
                    else:
                        return aggregated_shareable
                else:
                    return aggregated_shareable
            
            if global_weights is not None:
                # 加载测试数据和模型
                test_loader, input_dim = self.load_test_data()
                model = IDS_MLP(input_dim=input_dim).to(self.device)
                model.load_state_dict(global_weights)
                
                # 评估模型
                acc = self.evaluate_model(model, test_loader, self.current_round)
                
                # 保存模型 (可选)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                save_path = f"/tmp/global_model_round_{self.current_round}_{timestamp}.pt"
                torch.save(model.state_dict(), save_path)
                self.logger.info(f"[Round {self.current_round}] 💾 Saved global model to: {save_path}")
                
                # 将评估结果保存到上下文
                fl_ctx.set_prop(f"round_{self.current_round}_accuracy", acc)
            else:
                self.logger.warning(f"[Round {self.current_round}] ⚠️ Global weights is None")
                
        except Exception as e:
            self.logger.error(f"[Round {self.current_round}] ❌ Evaluation failed: {str(e)}")
            import traceback
            self.logger.error(f"[Round {self.current_round}] Traceback: {traceback.format_exc()}")
        
        return aggregated_shareable