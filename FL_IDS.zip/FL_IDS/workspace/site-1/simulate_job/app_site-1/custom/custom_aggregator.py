import logging
from collections import Counter, OrderedDict
from datetime import datetime
from sklearn.metrics import confusion_matrix, classification_report
from typing import Dict

import torch
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
import numpy as np

from nvflare.apis.shareable import Shareable
from nvflare.apis.dxo import DXO, DataKind
from nvflare.apis.fl_context import FLContext
from nvflare.app_common.aggregators.intime_accumulate_model_aggregator import InTimeAccumulateWeightedAggregator

from custom.unsw_nb15_model import IDS_MLP


class FlowerStyleAggregator(InTimeAccumulateWeightedAggregator):
    def __init__(self, expected_data_kind: str = DataKind.WEIGHTS, aggregation_weights: Dict[str, float] = None):
        super().__init__(expected_data_kind=expected_data_kind, aggregation_weights=aggregation_weights)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        self.current_round = 0
        
        # 🔧 调试：确认聚合权重配置
        self.logger.info(f"🔧 [Init] Aggregation weights configured: {aggregation_weights}")
        self.logger.info(f"🔧 [Init] Expected data kind: {expected_data_kind}")
        
        # 收集numpy权重
        self.collected_numpy_weights = {}

    def get_weights_from_model(self, model):
        """从模型获取numpy权重"""
        return [val.cpu().numpy() for _, val in model.state_dict().items()]

    def set_weights_to_model(self, model, numpy_weights):
        """将numpy权重设置到模型"""
        model_keys = list(model.state_dict().keys())
        params_dict = zip(model_keys, numpy_weights)
        state_dict = OrderedDict({k: torch.tensor(v) for k, v in params_dict})
        model.load_state_dict(state_dict, strict=True)

    def load_test_data(self):
        """加载测试数据"""
        df = pd.read_csv(self.test_path)
        X = torch.tensor(df.drop(columns=["label"]).values, dtype=torch.float32)
        y = torch.tensor(df["label"].values, dtype=torch.long)
        loader = DataLoader(TensorDataset(X, y), batch_size=128, shuffle=False)
        return loader, X.shape[1]

    def evaluate_model(self, model, test_loader, round_num):
        """评估模型性能"""
        model.eval()
        correct = 0
        total = 0
        all_preds = []
        all_labels = []

        with torch.no_grad():
            for batch_x, batch_y in test_loader:
                batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                outputs = model(batch_x)
                _, predicted = torch.max(outputs, 1)
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(batch_y.cpu().numpy())
                correct += (predicted == batch_y).sum().item()
                total += batch_y.size(0)

        acc = correct / total

        pred_dist = Counter(all_preds)
        true_dist = Counter(all_labels)
        cm = confusion_matrix(all_labels, all_preds)
        report = classification_report(all_labels, all_preds)

        self.logger.info(f"\n🌸 ========== Round {round_num} Global Model Evaluation ==========")
        self.logger.info(f"✅ [SERVER] Global Model Accuracy: {acc * 100:.2f}%")
        self.logger.info(f"🔢 Predicted Label Distribution: {pred_dist}")
        self.logger.info(f"📊 True Label Distribution: {true_dist}")
        self.logger.info(f"📉 Confusion Matrix:\n{cm}")
        self.logger.info(f"📋 Classification Report:\n{report}")
        self.logger.info(f"🌸 ============================================================\n")

        return acc

    def accept(self, shareable: Shareable, fl_ctx: FLContext) -> bool:
        """接收并处理客户端的numpy字典权重"""
        
        # 🔧 修复客户端名称获取逻辑
        client_name = "unknown"
        try:
            # 方法1: 从peer_ctx获取
            peer_ctx = fl_ctx.get_prop("peer_ctx")
            if peer_ctx and "peer_name" in peer_ctx:
                client_name = peer_ctx["peer_name"]
            else:
                # 方法2: 简化版本 - 直接从引擎获取
                engine = fl_ctx.get_engine()
                if hasattr(engine, 'get_current_peer_context'):
                    peer_context = engine.get_current_peer_context()
                    if peer_context and hasattr(peer_context, 'name'):
                        client_name = peer_context.name
                
                # 方法3: 从shareable headers中提取
                if client_name == "unknown" and "__headers__" in shareable:
                    headers = shareable["__headers__"]
                    if isinstance(headers, dict):
                        for key, value in headers.items():
                            if "client" in key.lower() or "site" in key.lower():
                                if isinstance(value, str) and ("site-" in value):
                                    client_name = value
                                    break
        except Exception as e:
            self.logger.warning(f"🌸 [accept] ⚠️ Error getting client name: {str(e)}")
        
        # 🔧 如果仍然无法获取正确的客户端名称，尝试从任务执行序列推断
        if client_name == "unknown" or client_name == "simulator_server":
            # 根据接收到的权重数量推断客户端
            current_count = len(self.collected_numpy_weights)
            if current_count == 0:
                client_name = "site-1"  # 第一个接收到的
            elif current_count == 1:
                client_name = "site-2"  # 第二个接收到的
            else:
                client_name = f"client-{current_count + 1}"
        
        self.logger.info(f"🌸 [accept] Receiving from {client_name} (corrected from identity)")
        self.logger.info(f"🔍 [accept] Shareable keys: {list(shareable.keys())}")
        
        try:
            # 提取numpy字典权重
            numpy_dict = None
            
            # 方法1: 直接从WEIGHTS获取
            if DataKind.WEIGHTS in shareable:
                weights_data = shareable[DataKind.WEIGHTS]
                if isinstance(weights_data, dict):
                    # 检查是否是numpy字典
                    sample_key = list(weights_data.keys())[0] if weights_data else None
                    if sample_key and isinstance(weights_data[sample_key], np.ndarray):
                        numpy_dict = weights_data
                        self.logger.info(f"🌸 [accept] Method 1: Got numpy dict with {len(weights_data)} keys")
                
            # 方法2: 从DXO提取
            elif "DXO" in shareable:
                dxo_data = shareable["DXO"]
                if isinstance(dxo_data, dict) and "data" in dxo_data:
                    data = dxo_data["data"]
                    if isinstance(data, dict):
                        sample_key = list(data.keys())[0] if data else None
                        if sample_key and isinstance(data[sample_key], np.ndarray):
                            numpy_dict = data
                            self.logger.info(f"🌸 [accept] Method 2: Got numpy dict from DXO with {len(data)} keys")
            
            # 验证numpy字典
            if numpy_dict and len(numpy_dict) > 0:
                # 检查第一个权重
                first_key = list(numpy_dict.keys())[0]
                first_weight = numpy_dict[first_key]
                if isinstance(first_weight, np.ndarray) and first_weight.size > 0:
                    self.collected_numpy_weights[client_name] = numpy_dict
                    self.logger.info(f"🌸 [accept] ✅ Stored numpy dict from {client_name}")
                    self.logger.info(f"🔍 [accept] Sample weight '{first_key}': shape={first_weight.shape}")
                    self.logger.info(f"📊 [accept] Total collected clients: {list(self.collected_numpy_weights.keys())}")
                    
                    # 调用父类确保兼容性
                    super().accept(shareable, fl_ctx)
                    return True
                else:
                    self.logger.warning(f"🌸 [accept] ⚠️ Empty numpy array from {client_name}")
            else:
                self.logger.warning(f"🌸 [accept] ⚠️ No valid numpy dict from {client_name}")
                
        except Exception as e:
            self.logger.error(f"🌸 [accept] ❌ Error processing {client_name}: {str(e)}")
            import traceback
            self.logger.error(f"🌸 [accept] Traceback: {traceback.format_exc()}")
        
        return False

    def aggregate(self, fl_ctx: FLContext) -> Shareable:
        """聚合numpy权重"""
        
        self.current_round += 1
        self.logger.info(f"🌸 [Round {self.current_round}] Starting numpy weights aggregation")
        self.logger.info(f"📊 [Round {self.current_round}] Collected from: {list(self.collected_numpy_weights.keys())}")
        
        if not self.collected_numpy_weights:
            self.logger.error(f"🌸 [Round {self.current_round}] ❌ No numpy weights collected")
            empty_dxo = DXO(data_kind=DataKind.WEIGHTS, data={})
            return empty_dxo.to_shareable()
        
        try:
            # 🌸 使用字典方式的权重聚合
            global_numpy_dict = None
            
            for client_name, client_numpy_dict in self.collected_numpy_weights.items():
                # 🔧 优先使用硬编码权重确保正确性
                hardcoded_weights = {"site-1": 0.2, "site-2": 0.8}
                
                if client_name in hardcoded_weights:
                    weight = hardcoded_weights[client_name]
                    self.logger.info(f"📊 [Round {self.current_round}] Processing {client_name} with hardcoded weight {weight}")
                elif self.aggregation_weights and client_name in self.aggregation_weights:
                    weight = self.aggregation_weights[client_name]
                    self.logger.info(f"📊 [Round {self.current_round}] Processing {client_name} with configured weight {weight}")
                else:
                    # 最后备选：均等权重
                    weight = 1.0 / len(self.collected_numpy_weights)
                    self.logger.warning(f"⚠️ [Round {self.current_round}] No weight found for {client_name}, using default {weight}")
                    self.logger.info(f"🔍 [Round {self.current_round}] Available configured: {list(self.aggregation_weights.keys()) if self.aggregation_weights else 'None'}")
                    self.logger.info(f"🔍 [Round {self.current_round}] Available hardcoded: {list(hardcoded_weights.keys())}")
                
                if global_numpy_dict is None:
                    # 初始化全局权重字典
                    global_numpy_dict = {}
                    for key, value in client_numpy_dict.items():
                        global_numpy_dict[key] = value * weight
                    self.logger.info(f"🔧 [Round {self.current_round}] Initialized with {client_name}")
                else:
                    # 累加权重
                    for key in global_numpy_dict.keys():
                        if key in client_numpy_dict:
                            global_numpy_dict[key] += client_numpy_dict[key] * weight
            
            if global_numpy_dict:
                # 验证聚合结果
                first_key = list(global_numpy_dict.keys())[0]
                first_weight = global_numpy_dict[first_key]
                self.logger.info(f"✅ [Round {self.current_round}] Numpy dict aggregation completed")
                self.logger.info(f"🔍 [Round {self.current_round}] Aggregated {len(global_numpy_dict)} weight tensors")
                self.logger.info(f"🔍 [Round {self.current_round}] Sample '{first_key}': shape={first_weight.shape}")
                
                # 🌸 评估聚合后的模型
                try:
                    test_loader, input_dim = self.load_test_data()
                    model = IDS_MLP(input_dim=input_dim).to(self.device)
                    
                    # 将numpy字典设置到模型
                    state_dict = {}
                    for key, numpy_value in global_numpy_dict.items():
                        state_dict[key] = torch.tensor(numpy_value)
                    model.load_state_dict(state_dict)
                    
                    # 评估模型
                    acc = self.evaluate_model(model, test_loader, self.current_round)
                    
                    # 保存模型
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    save_path = f"/tmp/global_model_round_{self.current_round}_{timestamp}.pt"
                    torch.save(model.state_dict(), save_path)
                    self.logger.info(f"💾 [Round {self.current_round}] Saved global model to: {save_path}")
                    
                    # 保存评估结果
                    fl_ctx.set_prop(f"round_{self.current_round}_accuracy", acc)
                    
                except Exception as eval_error:
                    self.logger.error(f"❌ [Round {self.current_round}] Evaluation failed: {str(eval_error)}")
                
                # 清空收集的权重
                self.collected_numpy_weights.clear()
                
                # 🔧 返回numpy字典（DXO兼容）
                result_dxo = DXO(data_kind=DataKind.WEIGHTS, data=global_numpy_dict)
                result_dxo.set_meta_prop("data_type", "numpy_dict")
                result_dxo.set_meta_prop("round", self.current_round)
                
                return result_dxo.to_shareable()
            
            else:
                self.logger.error(f"❌ [Round {self.current_round}] Failed to create global numpy dict")
                
        except Exception as e:
            self.logger.error(f"❌ [Round {self.current_round}] Numpy aggregation failed: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
        
        # 清空并返回空字典
        self.collected_numpy_weights.clear()
        empty_dxo = DXO(data_kind=DataKind.WEIGHTS, data={})
        return empty_dxo.to_shareable()