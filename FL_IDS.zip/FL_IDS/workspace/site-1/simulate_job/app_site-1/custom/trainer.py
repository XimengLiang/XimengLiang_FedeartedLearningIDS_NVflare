import logging
from collections import Counter, OrderedDict
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler  # 新增：特征标准化

from nvflare.apis.executor import Executor
from nvflare.apis.shareable import Shareable
from nvflare.apis.dxo import DXO, DataKind
from nvflare.apis.fl_context import FLContext
from nvflare.apis.signal import Signal

import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np

from custom.unsw_nb15_model import IDS_MLP


class CustomTrainer(Executor):
    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.train_path = None
        self.test_path = None

    def _set_client_paths(self, client_name):
        if client_name == "site-1":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site1_mixed.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-2":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site2_mixed.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        else:
            raise ValueError(f"Unsupported client name: {client_name}")

    def get_weights_as_dict(self, model):
        """将模型权重转换为numpy字典 - 兼容DXO"""
        state_dict = model.state_dict()
        numpy_dict = {}
        for key, value in state_dict.items():
            numpy_dict[key] = value.cpu().numpy()
        
        self.logger.info(f"📤 Converted model to numpy dict with {len(numpy_dict)} keys")
        return numpy_dict

    def set_weights_from_dict(self, model, numpy_dict):
        """从numpy字典设置模型权重"""
        if numpy_dict is None or len(numpy_dict) == 0:
            self.logger.warning("⚠️ No weights to set")
            return False
            
        try:
            state_dict = {}
            for key, numpy_value in numpy_dict.items():
                state_dict[key] = torch.tensor(numpy_value)
            
            model.load_state_dict(state_dict, strict=True)
            self.logger.info(f"✅ Successfully set weights from numpy dict with {len(numpy_dict)} keys")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Failed to set weights: {str(e)}")
            return False

    def get_weight_info(self, weights_dict):
        """获取权重信息用于调试"""
        if isinstance(weights_dict, dict):
            info = []
            for i, (key, value) in enumerate(list(weights_dict.items())[:3]):
                if isinstance(value, np.ndarray):
                    info.append(f"'{key}': shape={value.shape}, dtype={value.dtype}")
                else:
                    info.append(f"'{key}': type={type(value)}")
            return info
        else:
            return [f"Not a dict: {type(weights_dict)}"]

    def load_data(self):
        train_df = pd.read_csv(self.train_path)
        test_df = pd.read_csv(self.test_path)

        X_train = train_df.drop(columns=["label"]).values
        y_train = train_df["label"].values
        X_test = test_df.drop(columns=["label"]).values
        y_test = test_df["label"].values

        # 🔥 新增：特征标准化
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
        self.logger.info("📊 Applied StandardScaler to features")

        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.long)
        X_test = torch.tensor(X_test, dtype=torch.float32)
        y_test = torch.tensor(y_test, dtype=torch.long)

        train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=64, shuffle=True)
        test_loader = DataLoader(TensorDataset(X_test, y_test), batch_size=128, shuffle=False)

        return train_loader, test_loader, X_train.shape[1]

    def get_class_weights(self, train_loader):
        """🔥 新增：计算类别权重用于平衡损失"""
        labels = []
        for _, y in train_loader:
            labels.extend(y.numpy())
        
        class_counts = Counter(labels)
        total = sum(class_counts.values())
        
        # 计算反比例权重
        weight_0 = total / (2 * class_counts[0])  # 正常类
        weight_1 = total / (2 * class_counts[1])  # 攻击类
        
        weights = torch.tensor([weight_0, weight_1], dtype=torch.float32)
        self.logger.info(f"📊 Class weights: Normal={weight_0:.3f}, Attack={weight_1:.3f}")
        return weights

    def evaluate_model(self, model, test_loader, silent=False):
        model.eval()
        correct = 0
        total = 0
        all_preds = []
        all_labels = []

        with torch.no_grad():
            for batch_x, batch_y in test_loader:
                batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                outputs = model(batch_x)
                _, predicted = torch.max(outputs, 1)
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(batch_y.cpu().numpy())
                correct += (predicted == batch_y).sum().item()
                total += batch_y.size(0)

        acc = correct / total

        if not silent:
            pred_dist = Counter(all_preds)
            true_dist = Counter(all_labels)
            self.logger.info(f"✅ Test Accuracy: {acc * 100:.2f}%")
            self.logger.info(f"🔢 Predicted: {pred_dist}, True: {true_dist}")

            cm = confusion_matrix(all_labels, all_preds)
            report = classification_report(all_labels, all_preds)
            self.logger.info(f"📉 Confusion Matrix:\n{cm}")
            self.logger.info(f"📋 Classification Report:\n{report}")

        return acc

    def train_model(self, model, initial_numpy_dict=None, print_prefix=""):
            # 🔥 添加这些行 - 统一随机种子
        torch.manual_seed(42)
        np.random.seed(42)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(42)

        train_loader, test_loader, input_dim = self.load_data()
        
        if initial_numpy_dict is not None:
            if self.set_weights_from_dict(model, initial_numpy_dict):
                self.logger.info(f"{print_prefix}📥 Loaded initial weights from numpy dict")
            else:
                self.logger.warning(f"{print_prefix}⚠️ Failed to load initial weights, using random")
        else:
            self.logger.info(f"{print_prefix}🎲 Using random initialization")

        # 🔥 新增：类别平衡损失函数
        class_weights = self.get_class_weights(train_loader).to(self.device)
        criterion = nn.CrossEntropyLoss(weight=class_weights)
        
        # 🔥 新增：AdamW优化器 + 权重衰减
        optimizer = optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.01)
        
        # 🔥 新增：学习率调度器
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=4, gamma=0.7)

        self.logger.info(f"{print_prefix}📈 Starting Training with enhanced optimization:")
        
        # 🔥 增加训练轮数：8 → 12
        for epoch in range(12):
            model.train()
            total_loss = 0.0
            num_batches = 0
            
            for batch_x, batch_y in train_loader:
                batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                optimizer.zero_grad()
                output = model(batch_x)
                loss = criterion(output, batch_y)
                loss.backward()
                
                # 🔥 新增：梯度裁剪防止梯度爆炸
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                
                optimizer.step()
                total_loss += loss.item()
                num_batches += 1

            # 更新学习率
            scheduler.step()
            current_lr = scheduler.get_last_lr()[0]
            
            avg_loss = total_loss / num_batches
            acc = self.evaluate_model(model, test_loader, silent=True)
            
            self.logger.info(f"{print_prefix}[Epoch {epoch + 1}] Loss: {avg_loss:.4f} | Accuracy: {acc * 100:.2f}% | LR: {current_lr:.6f}")

        final_acc = self.evaluate_model(model, test_loader, silent=False)
        self.logger.info(f"{print_prefix}✅ Training completed. Final Accuracy: {final_acc * 100:.2f}%")

        return self.get_weights_as_dict(model)

    def execute(self, task_name: str, shareable: Shareable, fl_ctx: FLContext, abort_signal: Signal) -> Shareable:
        if abort_signal.triggered:
            self.logger.warning("🚫 Training aborted by server.")
            return shareable

        client_name = fl_ctx.get_identity_name()
        self._set_client_paths(client_name)
        prefix = f"[{client_name}] "

        self.logger.info(f"{prefix}Starting local training for task '{task_name}'")

        # 权重提取逻辑保持不变
        initial_numpy_dict = None
        
        try:
            self.logger.info(f"{prefix}🔍 Shareable keys: {list(shareable.keys())}")
            
            if DataKind.WEIGHTS in shareable:
                weights_data = shareable[DataKind.WEIGHTS]
                if isinstance(weights_data, dict):
                    sample_key = list(weights_data.keys())[0] if weights_data else None
                    if sample_key and isinstance(weights_data[sample_key], np.ndarray):
                        initial_numpy_dict = weights_data
                        self.logger.info(f"{prefix}📥 Method 1: Got numpy dict from WEIGHTS with {len(weights_data)} keys")
                        self.logger.info(f"{prefix}🔍 Weight info: {self.get_weight_info(weights_data)}")
                    elif sample_key and hasattr(weights_data[sample_key], 'cpu'):
                        initial_numpy_dict = {}
                        for key, value in weights_data.items():
                            initial_numpy_dict[key] = value.cpu().numpy()
                        self.logger.info(f"{prefix}📥 Method 1: Converted tensor dict to numpy dict")
                        self.logger.info(f"{prefix}🔍 Weight info: {self.get_weight_info(initial_numpy_dict)}")
                else:
                    self.logger.info(f"{prefix}ℹ️ WEIGHTS is not a dict: {type(weights_data)}")
            
            elif "DXO" in shareable:
                dxo_data = shareable["DXO"]
                
                if isinstance(dxo_data, dict) and "data" in dxo_data:
                    data = dxo_data["data"]
                    
                    if isinstance(data, dict):
                        sample_key = list(data.keys())[0] if data else None
                        if sample_key and isinstance(data[sample_key], np.ndarray):
                            initial_numpy_dict = data
                            self.logger.info(f"{prefix}📥 Method 2: Direct numpy dict from DXO")
                        elif sample_key and hasattr(data[sample_key], 'cpu'):
                            initial_numpy_dict = {}
                            for key, value in data.items():
                                initial_numpy_dict[key] = value.cpu().numpy()
                            self.logger.info(f"{prefix}📥 Method 2: Converted DXO tensor dict to numpy")
                        
                        if initial_numpy_dict:
                            self.logger.info(f"{prefix}🔍 Weight info: {self.get_weight_info(initial_numpy_dict)}")
            
            if initial_numpy_dict is None:
                self.logger.warning(f"{prefix}⚠️ No valid initial weights found, using random initialization")
            
        except Exception as e:
            self.logger.error(f"{prefix}❌ Error extracting weights: {str(e)}")
            initial_numpy_dict = None

        # 创建模型并训练
        _, _, input_dim = self.load_data()
        model = IDS_MLP(input_dim=input_dim).to(self.device)
        
        trained_numpy_dict = self.train_model(model, initial_numpy_dict, prefix)

        # 发送结果
        try:
            self.logger.info(f"{prefix}📤 Preparing to send numpy dict with {len(trained_numpy_dict)} keys")
            self.logger.info(f"{prefix}🔍 Sending weight info: {self.get_weight_info(trained_numpy_dict)}")
            
            result_dxo = DXO(data_kind=DataKind.WEIGHTS, data=trained_numpy_dict)
            result_dxo.set_meta_prop("NUM_STEPS_CURRENT_ROUND", 12)  # 更新为12
            result_dxo.set_meta_prop("client_name", client_name)
            result_dxo.set_meta_prop("data_type", "numpy_dict")
            
            result_shareable = result_dxo.to_shareable()
            self.logger.info(f"{prefix}✅ Successfully created shareable with numpy dict")
            
            return result_shareable
            
        except Exception as e:
            self.logger.error(f"{prefix}❌ Error creating result shareable: {str(e)}")
            import traceback
            self.logger.error(f"{prefix}Traceback: {traceback.format_exc()}")
            return Shareable()