import logging
from collections import Counter
from datetime import datetime
from sklearn.metrics import confusion_matrix, classification_report

import torch
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset

from nvflare.apis.executor import Executor
from nvflare.apis.shareable import Shareable
from nvflare.apis.dxo import DXO, DataKind
from nvflare.apis.fl_context import FLContext
from nvflare.apis.signal import Signal

from custom.unsw_nb15_model import IDS_MLP


class ServerEvaluator(Executor):
    """借鉴Flower框架的服务器端评估器"""
    
    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"

    def load_test_data(self):
        """加载测试数据"""
        df = pd.read_csv(self.test_path)
        X = torch.tensor(df.drop(columns=["label"]).values, dtype=torch.float32)
        y = torch.tensor(df["label"].values, dtype=torch.long)
        loader = DataLoader(TensorDataset(X, y), batch_size=128, shuffle=False)
        return loader, X.shape[1]

    def evaluate_global_model(self, weights_dict, server_round):
        """评估全局模型 - 类似Flower的evaluate函数"""
        try:
            # 加载测试数据和模型
            test_loader, input_dim = self.load_test_data()
            model = IDS_MLP(input_dim=input_dim).to(self.device)
            model.load_state_dict(weights_dict)
            
            # 评估模型
            model.eval()
            correct = 0
            total = 0
            all_preds = []
            all_labels = []
            
            with torch.no_grad():
                for batch_x, batch_y in test_loader:
                    batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                    outputs = model(batch_x)
                    _, predicted = torch.max(outputs, 1)
                    all_preds.extend(predicted.cpu().numpy())
                    all_labels.extend(batch_y.cpu().numpy())
                    correct += (predicted == batch_y).sum().item()
                    total += batch_y.size(0)
            
            accuracy = correct / total
            
            # 详细评估报告
            pred_dist = Counter(all_preds)
            true_dist = Counter(all_labels)
            cm = confusion_matrix(all_labels, all_preds)
            report = classification_report(all_labels, all_preds)
            
            # 类似Flower的日志格式
            self.logger.info(f"\n🌸 ========== Round {server_round} Global Model Evaluation ==========")
            self.logger.info(f"✅ Global model accuracy: {accuracy * 100:.4f}%")
            self.logger.info(f"🔢 Predicted distribution: {pred_dist}")
            self.logger.info(f"📊 True distribution: {true_dist}")
            self.logger.info(f"📉 Confusion Matrix:\n{cm}")
            self.logger.info(f"📋 Detailed Report:\n{report}")
            
            # 保存模型 (类似Flower在最后一轮保存)
            if server_round >= 3:  # 最后一轮或指定轮次
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                save_path = f"/tmp/final_global_model_round_{server_round}_{timestamp}.pt"
                torch.save(model.state_dict(), save_path)
                self.logger.info(f"💾 Final model saved to: {save_path}")
            
            self.logger.info(f"🌸 ============================================================\n")
            
            return {
                "accuracy": accuracy,
                "dataset_size": total,
                "confusion_matrix": cm.tolist(),
                "predictions_distribution": dict(pred_dist),
                "true_distribution": dict(true_dist)
            }
            
        except Exception as e:
            self.logger.error(f"❌ Global model evaluation failed: {str(e)}")
            return {"accuracy": 0.0, "error": str(e)}

    def execute(self, task_name: str, shareable: Shareable, fl_ctx: FLContext, abort_signal: Signal) -> Shareable:
        """执行评估任务"""
        if abort_signal.triggered:
            self.logger.warning("🚫 Evaluation aborted.")
            return shareable

        # 获取当前轮数
        server_round = fl_ctx.get_prop("current_round", 1)
        
        self.logger.info(f"🌸 [Round {server_round}] Starting global model evaluation...")

        # 提取全局模型权重
        global_weights = None
        try:
            if DataKind.WEIGHTS in shareable:
                global_weights = shareable[DataKind.WEIGHTS]
            elif "DXO" in shareable:
                dxo_data = shareable["DXO"]
                if isinstance(dxo_data, dict) and "data" in dxo_data:
                    global_weights = dxo_data["data"]
                elif hasattr(dxo_data, 'data'):
                    global_weights = dxo_data.data
                    
            if global_weights and isinstance(global_weights, dict) and len(global_weights) > 0:
                # 验证权重
                sample_key = list(global_weights.keys())[0]
                sample_weight = global_weights[sample_key]
                if hasattr(sample_weight, 'numel') and sample_weight.numel() > 0:
                    # 执行评估
                    eval_results = self.evaluate_global_model(global_weights, server_round)
                    
                    # 将结果保存到上下文
                    fl_ctx.set_prop(f"round_{server_round}_eval_results", eval_results)
                    
                    self.logger.info(f"🌸 [Round {server_round}] ✅ Global evaluation completed successfully")
                else:
                    self.logger.warning(f"🌸 [Round {server_round}] ⚠️ Empty weights detected")
            else:
                self.logger.warning(f"🌸 [Round {server_round}] ⚠️ No valid weights found for evaluation")
                
        except Exception as e:
            self.logger.error(f"🌸 [Round {server_round}] ❌ Evaluation failed: {str(e)}")

        return shareable