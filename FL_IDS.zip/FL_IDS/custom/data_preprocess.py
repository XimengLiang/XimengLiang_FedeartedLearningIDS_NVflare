import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import LabelEncoder
from sklearn.utils import shuffle
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif, VarianceThreshold
from sklearn.ensemble import RandomForestClassifier
from collections import Counter
import warnings
warnings.filterwarnings('ignore')

rng = np.random.default_rng(42)  # 复现实验

def inject_label_noise(df, label_col="label", noise_rate=0.2, num_classes=2):
    """对称标签噪声：随机把 noise_rate 比例的标签改成其他类别"""
    noisy_df = df.copy()
    y = noisy_df[label_col].to_numpy()
    idx = rng.choice(len(y), size=int(len(y) * noise_rate), replace=False)
    for i in idx:
        old = y[i]
        if num_classes == 2:
            y[i] = 1 - old  # 二分类直接翻转
        else:
            candidates = [c for c in range(num_classes) if c != old]
            y[i] = rng.choice(candidates)
    noisy_df[label_col] = y
    return noisy_df

def inject_asymmetric_noise(df, label_col="label", noise_rate=0.2, flip_from=0, flip_to=1):
    """非对称标签噪声：只把一部分 flip_from 翻成 flip_to"""
    noisy_df = df.copy()
    y = noisy_df[label_col].to_numpy()
    idx_candidates = np.where(y == flip_from)[0]
    flip_size = int(len(idx_candidates) * noise_rate)
    if flip_size > 0:
        idx_to_flip = rng.choice(idx_candidates, size=flip_size, replace=False)
        y[idx_to_flip] = flip_to
    noisy_df[label_col] = y
    return noisy_df

def label_flip_stats(df_before, df_after, label_col="label"):
    a = df_before[label_col].to_numpy()
    b = df_after[label_col].to_numpy()
    flips = int(np.sum(a != b))
    return flips, dict(pd.Series(b).value_counts())

# 🚀 新增：冗余特征移除功能
def remove_redundant_features(train_df, test_df, target_features=25, verbose=True):
    """
    移除冗余特征的综合策略 - 针对高相关性特征优化
    """
    if verbose:
        print(f"\n🎯 开始冗余特征移除：{train_df.shape[1]-1} → {target_features} 特征")
    
    # 分离特征和标签
    X_train = train_df.drop(['label'], axis=1)
    y_train = train_df['label']
    X_test = test_df.drop(['label'], axis=1)
    
    original_features = X_train.columns.tolist()
    n_original = len(original_features)
    
    if verbose:
        print(f"📊 原始特征数量: {n_original}")

    # 步骤1: 移除低方差特征
    if verbose:
        print("🔍 步骤1: 移除低方差特征...")
    
    # 🔧 调整方差阈值，更积极地移除低方差特征
    variance_threshold = 0.02  # 从0.01提高到0.02
    selector_var = VarianceThreshold(threshold=variance_threshold)
    X_train_var = selector_var.fit_transform(X_train)
    X_test_var = selector_var.transform(X_test)
    
    var_features = [original_features[i] for i in selector_var.get_support(indices=True)]
    removed_var = n_original - len(var_features)
    
    if verbose:
        print(f"   移除了 {removed_var} 个低方差特征，剩余 {len(var_features)} 个")

    # 步骤2: 🚀 增强的高相关性特征移除
    if verbose:
        print("🔍 步骤2: 增强的高相关性特征移除...")
    
    X_train_var_df = pd.DataFrame(X_train_var, columns=var_features)
    corr_matrix = X_train_var_df.corr().abs()
    
    # 🔧 更严格的相关性阈值 - 从0.95降低到0.85
    correlation_threshold = 0.85  # 更严格的阈值
    
    # 🚀 改进的相关性特征移除策略
    features_to_remove = set()
    
    # 计算与标签的相关性，保留更重要的特征
    label_correlations = {}
    for feature in var_features:
        corr_with_label = abs(X_train_var_df[feature].corr(y_train))
        label_correlations[feature] = corr_with_label if not pd.isna(corr_with_label) else 0
    
    # 找出所有高相关性特征对
    high_corr_pairs = []
    for i in range(len(var_features)):
        for j in range(i+1, len(var_features)):
            corr_val = corr_matrix.iloc[i, j]
            if corr_val > correlation_threshold:
                feat1, feat2 = var_features[i], var_features[j]
                high_corr_pairs.append((feat1, feat2, corr_val))
    
    if verbose:
        print(f"   发现 {len(high_corr_pairs)} 对高相关性特征 (>{correlation_threshold})")
    
    # 🚀 智能移除策略：保留与标签相关性更高的特征
    for feat1, feat2, corr_val in high_corr_pairs:
        if feat1 not in features_to_remove and feat2 not in features_to_remove:
            # 比较与标签的相关性
            corr1 = label_correlations.get(feat1, 0)
            corr2 = label_correlations.get(feat2, 0)
            
            if corr1 > corr2:
                features_to_remove.add(feat2)
                if verbose and len(features_to_remove) <= 10:  # 只显示前10个
                    print(f"     移除 {feat2} (与{feat1}相关{corr_val:.3f}, 标签相关性: {corr2:.3f} < {corr1:.3f})")
            else:
                features_to_remove.add(feat1)
                if verbose and len(features_to_remove) <= 10:
                    print(f"     移除 {feat1} (与{feat2}相关{corr_val:.3f}, 标签相关性: {corr1:.3f} < {corr2:.3f})")
    
    # 保留的特征
    corr_features = [f for f in var_features if f not in features_to_remove]
    
    # 更新数据
    X_train_corr = X_train_var_df[corr_features].values
    X_test_corr = pd.DataFrame(X_test_var, columns=var_features)[corr_features].values
    
    if verbose:
        print(f"   移除了 {len(features_to_remove)} 个高相关性特征，剩余 {len(corr_features)} 个")
        if len(features_to_remove) > 10:
            print(f"   (还有 {len(features_to_remove)-10} 个特征未显示)")

    # 步骤3: 基于统计测试的特征选择
    if len(corr_features) > target_features:
        if verbose:
            print("🔍 步骤3: 基于统计测试的特征选择...")
        
        # 🔧 调整选择数量，留更多余地给随机森林
        k_features = min(target_features + 15, len(corr_features))  # 从+10改为+15
        selector_f = SelectKBest(score_func=f_classif, k=k_features)
        X_train_f = selector_f.fit_transform(X_train_corr, y_train)
        X_test_f = selector_f.transform(X_test_corr)
        
        f_features = [corr_features[i] for i in selector_f.get_support(indices=True)]
        f_scores = selector_f.scores_[selector_f.get_support()]
        
        if verbose:
            print(f"   F-统计量选择了 {len(f_features)} 个特征")
    else:
        X_train_f = X_train_corr
        X_test_f = X_test_corr
        f_features = corr_features
        f_scores = np.ones(len(f_features))

    # 步骤4: 🚀 增强的随机森林特征选择
    if len(f_features) > target_features:
        if verbose:
            print("🔍 步骤4: 增强的随机森林重要性特征选择...")
        
        # 🔧 调整随机森林参数，提高特征选择质量
        rf = RandomForestClassifier(
            n_estimators=200,      # 从100增加到200
            random_state=42, 
            n_jobs=-1,
            max_depth=15,          # 从10增加到15
            min_samples_split=10,  # 新增参数
            min_samples_leaf=5     # 新增参数
        )
        rf.fit(X_train_f, y_train)
        
        # 获取特征重要性
        importance_scores = rf.feature_importances_
        
        # 🚀 改进的组合评分策略
        # 归一化F统计量和重要性分数
        f_scores_norm = f_scores / f_scores.max() if f_scores.max() > 0 else f_scores
        importance_norm = importance_scores / importance_scores.max() if importance_scores.max() > 0 else importance_scores
        
        # 🔧 调整权重：更重视随机森林重要性
        combined_scores = 0.3 * f_scores_norm + 0.7 * importance_norm  # 从0.5/0.5改为0.3/0.7
        
        # 选择top特征
        top_indices = np.argsort(combined_scores)[::-1][:target_features]
        final_features = [f_features[i] for i in top_indices]
        
        # 更新数据
        X_train_final = X_train_f[:, top_indices]
        X_test_final = X_test_f[:, top_indices]
        
        if verbose:
            print(f"   随机森林+F统计量选择了最终 {len(final_features)} 个特征")
            print(f"   Top 5 重要特征: {final_features[:5]}")
            
            # 🚀 显示特征重要性评分
            top_scores = [combined_scores[i] for i in top_indices[:5]]
            for i, (feat, score) in enumerate(zip(final_features[:5], top_scores)):
                print(f"     {i+1}. {feat}: {score:.4f}")
    else:
        final_features = f_features
        X_train_final = X_train_f
        X_test_final = X_test_f

    # 🚀 最终验证：检查剩余特征的相关性
    if verbose and len(final_features) > 1:
        print("🔍 最终验证: 检查剩余特征相关性...")
        final_corr_matrix = pd.DataFrame(X_train_final, columns=final_features).corr().abs()
        
        # 统计高相关性对数
        remaining_high_corr = 0
        max_corr = 0
        for i in range(len(final_features)):
            for j in range(i+1, len(final_features)):
                corr_val = final_corr_matrix.iloc[i, j]
                if corr_val > 0.8:  # 检查0.8以上的相关性
                    remaining_high_corr += 1
                max_corr = max(max_corr, corr_val)
        
        print(f"   剩余高相关性特征对 (>0.8): {remaining_high_corr}")
        print(f"   最高相关性: {max_corr:.3f}")
        
        if remaining_high_corr == 0:
            print("   ✅ 成功解决特征冗余问题！")
        elif remaining_high_corr <= 3:
            print("   ✅ 大幅改善特征冗余问题！")
        else:
            print("   ⚠️ 仍有部分特征冗余，可考虑进一步降低目标特征数")

    # 重建DataFrame
    train_df_selected = pd.DataFrame(X_train_final, columns=final_features)
    train_df_selected['label'] = y_train.values
    
    test_df_selected = pd.DataFrame(X_test_final, columns=final_features)
    test_df_selected['label'] = test_df['label'].values
    
    if verbose:
        print(f"✅ 特征选择完成: {n_original} → {len(final_features)} 特征")
        print(f"📊 特征减少比例: {((n_original - len(final_features)) / n_original * 100):.1f}%")
        
        # 保存增强的特征选择信息
        feature_info = {
            'original_features': original_features,
            'selected_features': final_features,
            'removed_low_variance': removed_var,
            'removed_high_correlation': len(features_to_remove),
            'final_count': len(final_features),
            'correlation_threshold_used': correlation_threshold,
            'remaining_high_corr_pairs': remaining_high_corr if 'remaining_high_corr' in locals() else 0,
            'max_remaining_correlation': max_corr if 'max_corr' in locals() else 0
        }
        
        import json
        with open(os.path.join(SAVE_DIR, "enhanced_feature_selection_info.json"), 'w') as f:
            json.dump(feature_info, f, indent=2)
        
        print(f"📁 增强特征选择信息已保存到: enhanced_feature_selection_info.json")
    
    return train_df_selected, test_df_selected

def handle_outliers(train_df, test_df, method='robust_clip', verbose=True):
    """
    处理异常值的综合策略
    
    Args:
        train_df: 训练数据
        test_df: 测试数据  
        method: 处理方法 ('robust_clip', 'iqr_clip', 'log_transform', 'winsorize')
        verbose: 是否打印详细信息
    
    Returns:
        处理后的训练和测试数据
    """
    if verbose:
        print(f"\n🔧 开始异常值处理，使用方法: {method}")
    
    # 分离特征和标签
    feature_cols = [col for col in train_df.columns if col != 'label']
    X_train = train_df[feature_cols].copy()
    X_test = test_df[feature_cols].copy()
    
    outlier_stats = {}
    
    for col in feature_cols:
        # 计算异常值统计（基于训练集）
        Q1 = X_train[col].quantile(0.25)
        Q3 = X_train[col].quantile(0.75)
        IQR = Q3 - Q1
        
        # IQR方法的异常值边界
        iqr_lower = Q1 - 1.5 * IQR
        iqr_upper = Q3 + 1.5 * IQR
        
        # 计算异常值比例
        train_outliers = ((X_train[col] < iqr_lower) | (X_train[col] > iqr_upper)).sum()
        outlier_ratio = train_outliers / len(X_train) * 100
        
        outlier_stats[col] = outlier_ratio
        
        # 只处理异常值比例超过5%的特征
        if outlier_ratio > 5.0:
            if method == 'robust_clip':
                # 使用更保守的边界（99.5%分位数）
                robust_lower = X_train[col].quantile(0.005)
                robust_upper = X_train[col].quantile(0.995)
                
                X_train[col] = X_train[col].clip(robust_lower, robust_upper)
                X_test[col] = X_test[col].clip(robust_lower, robust_upper)
                
            elif method == 'iqr_clip':
                # 使用IQR方法截断
                X_train[col] = X_train[col].clip(iqr_lower, iqr_upper)
                X_test[col] = X_test[col].clip(iqr_lower, iqr_upper)
                
            elif method == 'log_transform':
                # 对数变换（仅适用于正值）
                if (X_train[col] > 0).all() and (X_test[col] > 0).all():
                    X_train[col] = np.log1p(X_train[col])
                    X_test[col] = np.log1p(X_test[col])
                else:
                    # 如果有非正值，先shift再log
                    min_val = min(X_train[col].min(), X_test[col].min())
                    if min_val <= 0:
                        shift_val = abs(min_val) + 1
                        X_train[col] = np.log1p(X_train[col] + shift_val)
                        X_test[col] = np.log1p(X_test[col] + shift_val)
                    else:
                        X_train[col] = np.log1p(X_train[col])
                        X_test[col] = np.log1p(X_test[col])
                        
            elif method == 'winsorize':
                # Winsorization（将极值替换为分位数值）
                lower_percentile = X_train[col].quantile(0.01)
                upper_percentile = X_train[col].quantile(0.99)
                
                X_train[col] = np.where(X_train[col] < lower_percentile, lower_percentile, X_train[col])
                X_train[col] = np.where(X_train[col] > upper_percentile, upper_percentile, X_train[col])
                
                X_test[col] = np.where(X_test[col] < lower_percentile, lower_percentile, X_test[col])
                X_test[col] = np.where(X_test[col] > upper_percentile, upper_percentile, X_test[col])
    
    # 重建DataFrame
    train_df_processed = X_train.copy()
    train_df_processed['label'] = train_df['label'].values
    
    test_df_processed = X_test.copy()
    test_df_processed['label'] = test_df['label'].values
    
    if verbose:
        # 统计处理的特征
        processed_features = [col for col, ratio in outlier_stats.items() if ratio > 5.0]
        print(f"✅ 异常值处理完成")
        print(f"   处理了 {len(processed_features)} 个特征 (异常值比例>5%)")
        
        # 显示前5个异常值最多的特征
        top_outlier_features = sorted(outlier_stats.items(), key=lambda x: x[1], reverse=True)[:5]
        print("   异常值比例最高的5个特征:")
        for feat, ratio in top_outlier_features:
            status = "✓ 已处理" if ratio > 5.0 else "○ 跳过"
            print(f"     {feat}: {ratio:.1f}% {status}")
        
        # 保存异常值处理信息
        outlier_info = {
            'method': method,
            'processed_features': processed_features,
            'outlier_statistics': outlier_stats,
            'threshold': 5.0
        }
        
        import json
        with open(os.path.join(SAVE_DIR, "outlier_handling_info.json"), 'w') as f:
            json.dump(outlier_info, f, indent=2)
        
        print(f"📁 异常值处理信息已保存到: outlier_handling_info.json")
    
    return train_df_processed, test_df_processed


# 🚀 新增：特征标准化功能（推荐在异常值处理后使用）
def standardize_features(train_df, test_df, method='standard', verbose=True):
    """
    特征标准化
    
    Args:
        train_df: 训练数据
        test_df: 测试数据
        method: 标准化方法 ('standard', 'minmax', 'robust')
        verbose: 是否打印详细信息
    
    Returns:
        标准化后的训练和测试数据，以及标准化器
    """
    from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler
    
    if verbose:
        print(f"\n📏 开始特征标准化，使用方法: {method}")
    
    # 分离特征和标签
    feature_cols = [col for col in train_df.columns if col != 'label']
    X_train = train_df[feature_cols]
    X_test = test_df[feature_cols]
    
    # 选择标准化器
    if method == 'standard':
        scaler = StandardScaler()
    elif method == 'minmax':
        scaler = MinMaxScaler()
    elif method == 'robust':
        scaler = RobustScaler()  # 对异常值更鲁棒
    else:
        raise ValueError("method must be 'standard', 'minmax', or 'robust'")
    
    # 拟合并转换
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # 重建DataFrame
    train_df_scaled = pd.DataFrame(X_train_scaled, columns=feature_cols)
    train_df_scaled['label'] = train_df['label'].values
    
    test_df_scaled = pd.DataFrame(X_test_scaled, columns=feature_cols)
    test_df_scaled['label'] = test_df['label'].values
    
    if verbose:
        print(f"✅ 特征标准化完成，处理了 {len(feature_cols)} 个特征")
        
        # 检查标准化效果（仅对训练集）
        if method == 'standard':
            means = X_train_scaled.mean(axis=0)
            stds = X_train_scaled.std(axis=0)
            print(f"   标准化后均值范围: [{means.min():.3f}, {means.max():.3f}]")
            print(f"   标准化后标准差范围: [{stds.min():.3f}, {stds.max():.3f}]")
    
    return train_df_scaled, test_df_scaled, scaler

from sklearn.utils import shuffle

def split_dataset_evenly(df, num_clients=2, prefix="train_site", save_dir="./"):
    """
    将数据平均划分给多个客户端（Client），不考虑 label 分布。
    返回：{site-1: df1, site-2: df2, ...}
    """
    df = shuffle(df, random_state=42).reset_index(drop=True)
    total_samples = len(df)
    base_size = total_samples // num_clients
    remainder = total_samples % num_clients

    site_dfs = {}
    start_idx = 0
    for i in range(num_clients):
        end_idx = start_idx + base_size + (1 if i < remainder else 0)
        client_df = df.iloc[start_idx:end_idx].reset_index(drop=True)
        site_name = f"site-{i+1}"
        site_dfs[site_name] = client_df

        file_path = os.path.join(save_dir, f"{prefix}{i+1}_average.csv")
        client_df.to_csv(file_path, index=False)

        print(f"✅ {site_name} 样本数: {len(client_df)}，标签分布: \n{client_df['label'].value_counts()}")
        print(f"   📁 文件已保存至: {file_path}\n")

        start_idx = end_idx

    return site_dfs

    
# 设置文件路径
TRAIN_FILE = "./UNSW_NB15_training-set.csv"
TEST_FILE = "./UNSW_NB15_testing-set.csv"
SAVE_DIR = "./"

# 🔧 异常值处理参数
OUTLIER_METHOD = 'robust_clip'  # 可选: 'robust_clip', 'iqr_clip', 'log_transform', 'winsorize'
SCALING_METHOD = 'robust'       # 可选: 'standard', 'minmax', 'robust'

# 确保保存目录存在
os.makedirs(SAVE_DIR, exist_ok=True)

# 读取数据
train_df = pd.read_csv(TRAIN_FILE)
test_df = pd.read_csv(TEST_FILE)

print("原始标签种类:", train_df["attack_cat"].unique())
print(f"原始特征数量: {train_df.shape[1] - 2}")  # 减去id和attack_cat

### 🧪 第一步：检测原始数据中是否存在重复行
print("\n🧪 原始数据重复检测：")
print(f"训练集重复行数（含全部列）: {train_df.duplicated().sum()}")
print(f"测试集重复行数（含全部列）: {test_df.duplicated().sum()}")

# 合并攻击为一类，normal 为 0，其余为 1
def map_label(x):
    return 0 if isinstance(x, str) and x.lower() == "normal" else 1

# 在删除前备份原始数据用于后续比较
train_df_raw = train_df.copy()
test_df_raw = test_df.copy()

# 统一处理标签与无用列（并去除重复行）
keep_ratio = 1.0  # 🔧 可调整的重复数据保留比例 (0.0-1.0)

for name, df in [("train_df", train_df), ("test_df", test_df)]:
    df["label"] = df["attack_cat"].apply(map_label)
    df.drop(columns=["id", "attack_cat"], inplace=True, errors="ignore")

    # 找出所有重复行（不保留第一个）
    dup_mask = df.duplicated(keep=False)
    dup_df = df[dup_mask]
    unique_df = df[~dup_mask]

    # 保留指定比例的重复行，其余丢弃
    if not dup_df.empty:
        retained_duplicates = dup_df.sample(frac=keep_ratio, random_state=42)
        df_cleaned = pd.concat([unique_df, retained_duplicates], ignore_index=True).reset_index(drop=True)
        print(f"⚠️  {name} 含 {len(dup_df)} 条重复行，保留其中 {len(retained_duplicates)} 条（{int(keep_ratio * 100)}%）")
    else:
        df_cleaned = df.copy()
        print(f"✅  {name} 中没有重复行")

    # 替换原始 DataFrame 引用
    if name == "train_df":
        train_df = df_cleaned
    else:
        test_df = df_cleaned

# 合并训练与测试集用于统一编码
combined_df = pd.concat([train_df, test_df], axis=0)
object_cols = combined_df.select_dtypes(include=["object"]).columns

print(f"\n需要编码的列: {list(object_cols)}")

# 对每个 object 列使用 LabelEncoder 编码
encoders = {}
for col in object_cols:
    encoder = LabelEncoder()
    combined_values = pd.concat([train_df[col], test_df[col]])
    encoder.fit(combined_values.astype(str))

    train_df[col] = encoder.transform(train_df[col].astype(str))
    test_df[col] = encoder.transform(test_df[col].astype(str))
    encoders[col] = encoder

print("✅ 所有 object 类型列已编码完成")

train_df_encoder= train_df
test_df_encoder= test_df
train_df_encoder.to_csv(os.path.join(SAVE_DIR, "train_decoder.csv"), index=False)
test_df_encoder.to_csv(os.path.join(SAVE_DIR, "test_decoder.csv"), index=False)



# 🚀 应用冗余特征移除
TARGET_FEATURES =25  # 🔧 可调整的目标特征数量

print(f"\n{'='*60}")
print("🚀 开始应用冗余特征移除...")
train_df_processed, test_df_processed = remove_redundant_features(
    train_df, test_df, 
    target_features=TARGET_FEATURES,
    verbose=True
)

# 使用处理后的数据继续后续流程
train_df = train_df_processed
test_df = test_df_processed
print(f"{'='*60}")

# # 🚀 在这里添加异常值处理！
print(f"\n{'='*60}")
print("🔧 开始异常值处理...")

# # 可选的异常值处理方法：
# # 'robust_clip': 使用99.5%分位数截断（推荐，保守）
# # 'iqr_clip': 使用IQR方法截断（较激进）
# # 'log_transform': 对数变换（适合长尾分布）
# # 'winsorize': Winsorization（中等保守）

OUTLIER_METHOD = 'robust_clip'  # 🔧 可调整的异常值处理方法

train_df, test_df = handle_outliers(
    train_df, test_df, 
    method=OUTLIER_METHOD,
    verbose=True
)
print(f"{'='*60}")

# # 🚀 可选：添加特征标准化（推荐）
print(f"\n{'='*60}")
print("📏 开始特征标准化...")

# # 可选的标准化方法：
# # 'standard': StandardScaler（零均值，单位方差）
# # 'minmax': MinMaxScaler（缩放到[0,1]）
# # 'robust': RobustScaler（对异常值鲁棒，推荐）

SCALING_METHOD = 'robust'  # 🔧 可调整的标准化方法

train_df, test_df, scaler = standardize_features(
    train_df, test_df,
    method=SCALING_METHOD,
    verbose=True
)

# 按 label 拆分数据
train_attack = train_df[train_df["label"] == 1].copy()
train_normal = train_df[train_df["label"] == 0].copy()
test_attack = test_df[test_df["label"] == 1].copy()
test_normal = test_df[test_df["label"] == 0].copy()
test_set = test_df.copy()

# 检查拆分后的数据是否有重复
print("\n🧪 特征选择后各子集重复行数:")
print(f"train_attack 重复行数: {train_attack.duplicated().sum()}")
print(f"train_normal 重复行数: {train_normal.duplicated().sum()}")
print(f"test_attack 重复行数: {test_attack.duplicated().sum()}")
print(f"test_normal 重复行数: {test_normal.duplicated().sum()}")

# 保存文件
train_attack.to_csv(os.path.join(SAVE_DIR, "train_attack.csv"), index=False)
test_attack.to_csv(os.path.join(SAVE_DIR, "test_attack.csv"), index=False)
train_normal.to_csv(os.path.join(SAVE_DIR, "train_normal.csv"), index=False)
test_normal.to_csv(os.path.join(SAVE_DIR, "test_normal.csv"), index=False)
test_set.to_csv(os.path.join(SAVE_DIR, "test_set.csv"), index=False)

# print(f"\n✅ 数据预处理完成，特征已从原始数量优化到 {TARGET_FEATURES} 个，CSV 文件已保存至：", SAVE_DIR)

# # 设置比例
# ATTACK_RATIO_SITE1 = 0.70
# NORMAL_RATIO_SITE1 = 0.30
# ATTACK_RATIO_SITE2 = 0.30
# NORMAL_RATIO_SITE2 = 0.70

# # Site-1: 70% 攻击 + 30% 正常
# site1_attack = train_attack.sample(frac=ATTACK_RATIO_SITE1, random_state=42)
# site1_normal = train_normal.sample(frac=NORMAL_RATIO_SITE1, random_state=42)
# train_site1 = pd.concat([site1_attack, site1_normal])
# train_site1 = shuffle(train_site1, random_state=42).reset_index(drop=True)

# # Site-2: 70% 正常 + 30% 攻击
# site2_attack = train_attack.sample(frac=ATTACK_RATIO_SITE2, random_state=24)
# site2_normal = train_normal.sample(frac=NORMAL_RATIO_SITE2, random_state=24)
# train_site2 = pd.concat([site2_attack, site2_normal])
# train_site2 = shuffle(train_site2, random_state=24).reset_index(drop=True)

# # 保存为 CSV
# site1_file = os.path.join(SAVE_DIR, "train_site1_mixed.csv")
# site2_file = os.path.join(SAVE_DIR, "train_site2_mixed.csv")

# train_site1.to_csv(site1_file, index=False)
# train_site2.to_csv(site2_file, index=False)

# print("\n✅ 联邦训练集已生成：")
# print(f"   📁 Site-1 训练样本数: {len(train_site1)}，分布:\n{train_site1['label'].value_counts()}")
# print(f"   📁 Site-2 训练样本数: {len(train_site2)}，分布:\n{train_site2['label'].value_counts()}")
# print(f"\n📁 保存路径：{site1_file}, {site2_file}")
# print(f"\n🎯 最终数据摘要:")
# print(f"   - 原始特征数: ~42个")
# print(f"   - 优化后特征数: {TARGET_FEATURES}个")  
# print(f"   - 重复数据保留率: {int(keep_ratio * 100)}%")
# print(f"   - 特征减少率: {((42 - TARGET_FEATURES) / 42 * 100):.1f}%")

# 🔧 可调参数总结
print(f"\n🔧 可调参数说明:")
print(f"   - keep_ratio = {keep_ratio} (重复数据保留比例: 0.0-1.0)")
# print(f"   - TARGET_FEATURES = {TARGET_FEATURES} (目标特征数量)")
print(f"   - variance_threshold = 0.01 (低方差阈值)")
print(f"   - correlation_threshold = 0.95 (高相关性阈值)")
print(f"   - 在 remove_redundant_features() 函数中修改这些值")

print("\n🚀 开始平均划分训练数据到多个客户端")

NUM_CLIENTS = 5 # 🔧 可调，你可以设为 3、4、5 ...
split_dataset_evenly(train_df, num_clients=NUM_CLIENTS, prefix="train_site", save_dir=SAVE_DIR)
site_dfs = split_dataset_evenly(train_df, num_clients=NUM_CLIENTS, prefix="train_site", save_dir=SAVE_DIR)

# ===== 噪声注入计划（你可按需调整）=====
# 二分类建议：以非对称噪声为主，能更好模拟真实误标方向
noise_plan = {
    "site-1": {"type": "none"},                                 # 高质量，无噪声
    "site-2": {"type": "none"},
    "site-3": {"type": "asym", "rate": 0.40, "flip_from": 0, "flip_to": 1},  # 正常->攻击 
    "site-4": {"type": "asym", "rate": 0.60, "flip_from": 1, "flip_to": 0},  # 攻击->正常 
    "site-5": {"type": "sym",  "rate": 0.05},                                # 轻微对称噪声 5%
}

print("\n🎭 开始对各客户端注入噪声并另存为 *_noisy.csv ...")
for site_name, df_site in site_dfs.items():
    cfg = noise_plan.get(site_name, {"type": "none"})
    df_before = df_site

    if cfg["type"] == "sym":
        df_after = inject_label_noise(df_site, label_col="label", noise_rate=cfg["rate"], num_classes=2)
    elif cfg["type"] == "asym":
        df_after = inject_asymmetric_noise(df_site, label_col="label",
                                           noise_rate=cfg["rate"],
                                           flip_from=cfg.get("flip_from", 0),
                                           flip_to=cfg.get("flip_to", 1))
    else:
        df_after = df_site  # 无噪声

    flips, new_dist = label_flip_stats(df_before, df_after, label_col="label")
    print(f"🎯 {site_name}: 噪声类型={cfg['type']}, 翻转数={flips}, 新分布={new_dist}")

    # 保存加噪后的版本，建议新文件名避免覆盖原平均划分数据
    site_num = site_name.split("-")[1]  # 从 "site-1" 提取 1
    noisy_path = os.path.join(SAVE_DIR, f"train_site{site_num}_noisy.csv")

    df_after.to_csv(noisy_path, index=False)
    print(f"   💾 已保存加噪数据: {noisy_path}")
