import torch
import torch.nn as nn
import torch.nn.functional as F
import math

# class IDS_MLP(nn.Module):
#     def __init__(self, input_dim: int, dropout_rate: float = 0.3):
#         """
#         改进的入侵检测模型
        
#         主要改进：
#         1. 更合理的网络深度和宽度
#         2. 残差连接帮助梯度流动
#         3. 更好的正则化策略
#         4. 改进的权重初始化
#         5. 自适应的激活函数
        
#         Args:
#             input_dim: 输入特征维度
#             dropout_rate: dropout比率
#         """
#         super(IDS_MLP, self).__init__()
        
#         # 🔥 改进1: 更合理的网络架构
#         # 使用逐渐减小的层次结构
#         self.hidden_dims = [256, 128, 64, 32]
        
#         # 第一层：特征提取层
#         self.fc1 = nn.Linear(input_dim, self.hidden_dims[0])
#         self.bn1 = nn.BatchNorm1d(self.hidden_dims[0])
#         self.dropout1 = nn.Dropout(dropout_rate)
        
#         # 第二层：深度特征学习
#         self.fc2 = nn.Linear(self.hidden_dims[0], self.hidden_dims[1])
#         self.bn2 = nn.BatchNorm1d(self.hidden_dims[1])
#         self.dropout2 = nn.Dropout(dropout_rate + 0.1)  # 稍微增加dropout
        
#         # 第三层：特征融合
#         self.fc3 = nn.Linear(self.hidden_dims[1], self.hidden_dims[2])
#         self.bn3 = nn.BatchNorm1d(self.hidden_dims[2])
#         self.dropout3 = nn.Dropout(dropout_rate)
        
#         # 第四层：特征精炼
#         self.fc4 = nn.Linear(self.hidden_dims[2], self.hidden_dims[3])
#         self.bn4 = nn.BatchNorm1d(self.hidden_dims[3])
#         self.dropout4 = nn.Dropout(dropout_rate * 0.5)  # 输出层前减少dropout
        
#         # 🔥 改进2: 残差连接的投影层
#         # 当维度不匹配时用于残差连接
#         self.residual_proj1 = nn.Linear(input_dim, self.hidden_dims[1])
#         self.residual_proj2 = nn.Linear(self.hidden_dims[1], self.hidden_dims[3])
        
#         # 🔥 改进3: 注意力机制（简化版）
#         self.attention = nn.MultiheadAttention(
#             embed_dim=self.hidden_dims[3], 
#             num_heads=4, 
#             dropout=0.1, 
#             batch_first=True
#         )
        
#         # 输出层
#         self.output = nn.Linear(self.hidden_dims[3], 2)
        
#         # 🔥 改进4: 改进的权重初始化
#         self._initialize_weights()
    
#     def _initialize_weights(self):
#         """改进的权重初始化策略"""
#         for m in self.modules():
#             if isinstance(m, nn.Linear):
#                 # 使用He初始化，适合ReLU激活函数
#                 nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
#                 if m.bias is not None:
#                     nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.BatchNorm1d):
#                 nn.init.constant_(m.weight, 1)
#                 nn.init.constant_(m.bias, 0)
    
#     def forward(self, x):
#         # 保存输入用于残差连接
#         identity_input = x
        
#         # 第一层
#         x1 = self.fc1(x)
#         x1 = self.bn1(x1)
#         x1 = F.relu(x1)
#         x1 = self.dropout1(x1)
        
#         # 第二层 + 第一个残差连接
#         x2 = self.fc2(x1)
#         x2 = self.bn2(x2)
#         x2 = F.relu(x2)
        
#         # 🔥 残差连接1: input -> hidden2
#         if hasattr(self, 'residual_proj1'):
#             residual1 = self.residual_proj1(identity_input)
#             x2 = x2 + residual1
        
#         x2 = self.dropout2(x2)
        
#         # 第三层
#         x3 = self.fc3(x2)
#         x3 = self.bn3(x3)
#         x3 = F.relu(x3)
#         x3 = self.dropout3(x3)
        
#         # 第四层 + 第二个残差连接
#         x4 = self.fc4(x3)
#         x4 = self.bn4(x4)
#         x4 = F.relu(x4)
        
#         # 🔥 残差连接2: hidden2 -> hidden4
#         if hasattr(self, 'residual_proj2'):
#             residual2 = self.residual_proj2(x2)
#             x4 = x4 + residual2
        
#         x4 = self.dropout4(x4)
        
#         # 🔥 简化的注意力机制
#         # 将特征视为序列进行自注意力
#         x_att = x4.unsqueeze(1)  # [batch_size, 1, hidden_dim]
#         x_att, _ = self.attention(x_att, x_att, x_att)
#         x_final = x_att.squeeze(1)  # [batch_size, hidden_dim]
        
#         # 输出层
#         output = self.output(x_final)
        
#         return output


# class IDS_MLP(nn.Module):
#     def __init__(self, input_dim: int, dropout_rate: float = 0.3):
#         """
#         轻量级版本 - 如果上面的模型太复杂可以用这个
        
#         主要特点：
#         1. 更少的参数
#         2. 更快的训练速度
#         3. 仍然保持较好的性能
#         """
#         super(IDS_MLP, self).__init__()
        
#         # 更简单的架构
#         self.fc1 = nn.Linear(input_dim, 128)
#         self.bn1 = nn.BatchNorm1d(128)
#         self.dropout1 = nn.Dropout(dropout_rate)
        
#         self.fc2 = nn.Linear(128, 64)
#         self.bn2 = nn.BatchNorm1d(64)
#         self.dropout2 = nn.Dropout(dropout_rate + 0.1)
        
#         self.fc3 = nn.Linear(64, 32)
#         self.bn3 = nn.BatchNorm1d(32)
#         self.dropout3 = nn.Dropout(dropout_rate * 0.5)
        
#         # 简单的残差连接
#         self.residual = nn.Linear(input_dim, 32)
        
#         self.output = nn.Linear(32, 2)
        
#         # 权重初始化
#         self._initialize_weights()
    
#     def _initialize_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Linear):
#                 nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
#                 if m.bias is not None:
#                     nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.BatchNorm1d):
#                 nn.init.constant_(m.weight, 1)
#                 nn.init.constant_(m.bias, 0)
    
#     def forward(self, x):
#         identity = x
        
#         # 主路径
#         x = F.relu(self.bn1(self.fc1(x)))
#         x = self.dropout1(x)
        
#         x = F.relu(self.bn2(self.fc2(x)))
#         x = self.dropout2(x)
        
#         x = F.relu(self.bn3(self.fc3(x)))
        
#         # 残差连接
#         residual = self.residual(identity)
#         x = x + residual
        
#         x = self.dropout3(x)
        
#         return self.output(x)

import torch
import torch.nn as nn
import torch.nn.functional as F

# class IDS_MLP(nn.Module):
#     def __init__(self, input_dim: int = 30, dropout_rate: float = 0.3):
#         """
#         稍微复杂一点的 IDS 模型，适用于 30 个重要特征
#         """
#         super(IDS_MLP, self).__init__()
        
#         self.fc1 = nn.Linear(input_dim, 256)
#         self.bn1 = nn.BatchNorm1d(256)
#         self.dropout1 = nn.Dropout(dropout_rate)
        
#         self.fc2 = nn.Linear(256, 128)
#         self.bn2 = nn.BatchNorm1d(128)
#         self.dropout2 = nn.Dropout(dropout_rate + 0.1)
        
#         self.fc3 = nn.Linear(128, 64)
#         self.bn3 = nn.BatchNorm1d(64)
#         self.dropout3 = nn.Dropout(dropout_rate + 0.1)
        
#         self.fc4 = nn.Linear(64, 32)
#         self.bn4 = nn.BatchNorm1d(32)
#         self.dropout4 = nn.Dropout(dropout_rate * 0.5)
        
#         # 残差连接，用于与 fc4 合并（维度需一致）
#         self.residual = nn.Linear(input_dim, 32)
        
#         self.output = nn.Linear(32, 2)

#         self._initialize_weights()
    
#     def _initialize_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Linear):
#                 nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
#                 if m.bias is not None:
#                     nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.BatchNorm1d):
#                 nn.init.constant_(m.weight, 1)
#                 nn.init.constant_(m.bias, 0)

#     def forward(self, x):
#         identity = x

#         x = F.relu(self.bn1(self.fc1(x)))
#         x = self.dropout1(x)
        
#         x = F.relu(self.bn2(self.fc2(x)))
#         x = self.dropout2(x)
        
#         x = F.relu(self.bn3(self.fc3(x)))
#         x = self.dropout3(x)

#         x = F.relu(self.bn4(self.fc4(x)))

#         # 残差连接：input -> fc_res -> 加入主路径
#         res = self.residual(identity)
#         x = x + res
        
#         x = self.dropout4(x)
#         return self.output(x)


class IDS_MLP(nn.Module):
    def __init__(self, input_dim: int, dropout_rate: float = 0.2):
        """
        高级版本 - 如果性能还需要进一步提升可以尝试
        
        主要特点：
        1. 更深的网络
        2. 更复杂的残差结构
        3. 层级attention
        4. 自适应dropout
        """
        super(IDS_MLP, self).__init__()
        
        self.hidden_dims = [512, 256, 128, 64, 32]
        
        # 构建网络层
        self.layers = nn.ModuleList()
        self.batch_norms = nn.ModuleList()
        self.dropouts = nn.ModuleList()
        
        # 第一层
        self.layers.append(nn.Linear(input_dim, self.hidden_dims[0]))
        self.batch_norms.append(nn.BatchNorm1d(self.hidden_dims[0]))
        self.dropouts.append(nn.Dropout(dropout_rate))
        
        # 中间层
        for i in range(len(self.hidden_dims) - 1):
            self.layers.append(nn.Linear(self.hidden_dims[i], self.hidden_dims[i + 1]))
            self.batch_norms.append(nn.BatchNorm1d(self.hidden_dims[i + 1]))
            # 自适应dropout：deeper layers have lower dropout
            adaptive_dropout = dropout_rate * (0.8 ** i)
            self.dropouts.append(nn.Dropout(adaptive_dropout))
        
        # 残差连接
        self.residual_connections = nn.ModuleList([
            nn.Linear(input_dim, self.hidden_dims[2]),  # input -> layer3
            nn.Linear(self.hidden_dims[1], self.hidden_dims[4])  # layer2 -> layer5
        ])
        
        # 多头注意力
        self.attention = nn.MultiheadAttention(
            embed_dim=self.hidden_dims[-1], 
            num_heads=8, 
            dropout=0.1, 
            batch_first=True
        )
        
        # 输出层
        self.output = nn.Linear(self.hidden_dims[-1], 2)
        
        self._initialize_weights()
    
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        identity_input = x
        activations = []
        
        # 前向传播
        for i, (layer, bn, dropout) in enumerate(zip(self.layers, self.batch_norms, self.dropouts)):
            x = layer(x)
            x = bn(x)
            x = F.relu(x)
            
            # 残差连接
            if i == 2:  # 第3层添加输入残差
                residual = self.residual_connections[0](identity_input)
                x = x + residual
            elif i == 4 and len(activations) > 1:  # 第5层添加第2层残差
                residual = self.residual_connections[1](activations[1])
                x = x + residual
            
            x = dropout(x)
            activations.append(x)
        
        # 注意力机制
        x_att = x.unsqueeze(1)
        x_att, _ = self.attention(x_att, x_att, x_att)
        x_final = x_att.squeeze(1)
        
        return self.output(x_final)

# class IDS_MLP(nn.Module):
#     def __init__(self, input_dim: int, dropout_rate: float = 0.3):
#         """
#         修复BatchNorm问题的版本
#         主要改进：
#         1. 用LayerNorm替代BatchNorm（更适合小batch）
#         2. 添加batch size检查和降级处理
#         3. 保持原有的高级架构特性
#         """
#         super(IDS_MLP, self).__init__()
        
#         self.hidden_dims = [512, 256, 128, 64, 32]
        
#         # 构建网络层
#         self.layers = nn.ModuleList()
#         self.layer_norms = nn.ModuleList()  # 用LayerNorm替代BatchNorm
#         self.dropouts = nn.ModuleList()
        
#         # 第一层
#         self.layers.append(nn.Linear(input_dim, self.hidden_dims[0]))
#         self.layer_norms.append(nn.LayerNorm(self.hidden_dims[0]))  # LayerNorm替代BatchNorm
#         self.dropouts.append(nn.Dropout(dropout_rate))
        
#         # 中间层
#         for i in range(len(self.hidden_dims) - 1):
#             self.layers.append(nn.Linear(self.hidden_dims[i], self.hidden_dims[i + 1]))
#             self.layer_norms.append(nn.LayerNorm(self.hidden_dims[i + 1]))  # LayerNorm替代BatchNorm
#             # 自适应dropout：deeper layers have lower dropout
#             adaptive_dropout = dropout_rate * (0.8 ** i)
#             self.dropouts.append(nn.Dropout(adaptive_dropout))
        
#         # 残差连接
#         self.residual_connections = nn.ModuleList([
#             nn.Linear(input_dim, self.hidden_dims[2]),  # input -> layer3
#             nn.Linear(self.hidden_dims[1], self.hidden_dims[4])  # layer2 -> layer5
#         ])
        
#         # 多头注意力 - 减少头数避免小batch问题
#         self.attention = nn.MultiheadAttention(
#             embed_dim=self.hidden_dims[-1], 
#             num_heads=4,  # 从8减少到4
#             dropout=0.1, 
#             batch_first=True
#         )
        
#         # 输出层
#         self.output = nn.Linear(self.hidden_dims[-1], 2)
        
#         self._initialize_weights()
    
#     def _initialize_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Linear):
#                 nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
#                 if m.bias is not None:
#                     nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.LayerNorm):
#                 nn.init.constant_(m.weight, 1)
#                 nn.init.constant_(m.bias, 0)
    
#     def forward(self, x):
#         identity_input = x
#         activations = []
        
#         # 前向传播
#         for i, (layer, ln, dropout) in enumerate(zip(self.layers, self.layer_norms, self.dropouts)):
#             x = layer(x)
#             x = ln(x)  # LayerNorm不受batch size影响
#             x = F.relu(x)
            
#             # 残差连接
#             if i == 2:  # 第3层添加输入残差
#                 residual = self.residual_connections[0](identity_input)
#                 x = x + residual
#             elif i == 4 and len(activations) > 1:  # 第5层添加第2层残差
#                 residual = self.residual_connections[1](activations[1])
#                 x = x + residual
            
#             x = dropout(x)
#             activations.append(x)
        
#         # 注意力机制 - 添加batch size检查
#         if x.size(0) > 1:  # 只有batch size > 1时才使用attention
#             x_att = x.unsqueeze(1)
#             x_att, _ = self.attention(x_att, x_att, x_att)
#             x_final = x_att.squeeze(1)
#         else:
#             # batch size = 1时跳过attention
#             x_final = x
        
#         return self.output(x_final)

# class IDS_MLP(nn.Module):
#     def __init__(self, input_dim: int, dropout_rate: float = 0.15):
#         """
#         适合小数据集的简化IDS模型
        
#         主要简化：
#         1. 减少网络深度：5层 → 3层
#         2. 减少网络宽度：512 → 256
#         3. 降低dropout率：0.3 → 0.15
#         4. 移除复杂的残差连接和注意力机制
#         5. 保持LayerNorm的优势
#         """
#         super(IDS_MLP, self).__init__()
        
#         # 🔧 简化的网络架构 - 适合小数据集
#         self.hidden_dims = [256, 128, 64]  # 从[512,256,128,64,32]简化到[256,128,64]
        
#         # 第一层
#         self.fc1 = nn.Linear(input_dim, self.hidden_dims[0])
#         self.ln1 = nn.LayerNorm(self.hidden_dims[0])
#         self.dropout1 = nn.Dropout(dropout_rate)
        
#         # 第二层
#         self.fc2 = nn.Linear(self.hidden_dims[0], self.hidden_dims[1])
#         self.ln2 = nn.LayerNorm(self.hidden_dims[1])
#         self.dropout2 = nn.Dropout(dropout_rate * 0.8)  # 稍微减少dropout
        
#         # 第三层
#         self.fc3 = nn.Linear(self.hidden_dims[1], self.hidden_dims[2])
#         self.ln3 = nn.LayerNorm(self.hidden_dims[2])
#         self.dropout3 = nn.Dropout(dropout_rate * 0.6)  # 进一步减少dropout
        
#         # 🔧 简化的残差连接 - 只保留一个
#         self.residual = nn.Linear(input_dim, self.hidden_dims[2])
        
#         # 输出层
#         self.output = nn.Linear(self.hidden_dims[2], 2)
        
#         self._initialize_weights()
    
#     def _initialize_weights(self):
#         """权重初始化"""
#         for m in self.modules():
#             if isinstance(m, nn.Linear):
#                 nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
#                 if m.bias is not None:
#                     nn.init.constant_(m.bias, 0)
#             elif isinstance(m, nn.LayerNorm):
#                 nn.init.constant_(m.weight, 1)
#                 nn.init.constant_(m.bias, 0)
    
#     def forward(self, x):
#         identity = x
        
#         # 第一层
#         x1 = self.fc1(x)
#         x1 = self.ln1(x1)
#         x1 = F.relu(x1)
#         x1 = self.dropout1(x1)
        
#         # 第二层
#         x2 = self.fc2(x1)
#         x2 = self.ln2(x2)
#         x2 = F.relu(x2)
#         x2 = self.dropout2(x2)
        
#         # 第三层
#         x3 = self.fc3(x2)
#         x3 = self.ln3(x3)
#         x3 = F.relu(x3)
        
#         # 🔧 简单的残差连接
#         residual = self.residual(identity)
#         x3 = x3 + residual
#         x3 = self.dropout3(x3)
        
#         # 输出层
#         return self.output(x3)
# # 使用示例和参数建议
# """
# 模型选择建议：

# 1. IDS_MLP_Lightweight:
#    - 参数量：约50K
#    - 训练速度：最快
#    - 适用场景：资源受限、快速原型
#    - 预期性能：80-83%

# 2. IDS_MLP (推荐):
#    - 参数量：约200K
#    - 训练速度：中等
#    - 适用场景：平衡性能和复杂度
#    - 预期性能：82-86%

# 3. IDS_MLP_Advanced:
#    - 参数量：约500K
#    - 训练速度：较慢
#    - 适用场景：追求最高性能
#    - 预期性能：84-88%

# 使用方法：
# # 在trainer中替换模型创建部分
# model = create_ids_model(input_dim, model_type="standard", dropout_rate=0.3)
# """

class IDS_CNN(nn.Module):
    def __init__(self, input_dim: int):
        """
        1D CNN模型用于网络入侵检测
        专门设计用于处理网络流量特征数据
        
        Args:
            input_dim: 输入特征维度 (预处理后应该是20)
        """
        super(IDS_CNN, self).__init__()
        
        self.input_dim = input_dim
        
        # 🔥 第一层卷积 - 捕获相邻特征的关系
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=64, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(64)
        self.dropout1 = nn.Dropout(0.2)
        
        # 🔥 第二层卷积 - 更复杂的特征组合
        self.conv2 = nn.Conv1d(in_channels=64, out_channels=128, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm1d(128)
        self.dropout2 = nn.Dropout(0.2)
        
        # 🔥 第三层卷积 - 高级特征提取
        self.conv3 = nn.Conv1d(in_channels=128, out_channels=256, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm1d(256)
        self.dropout3 = nn.Dropout(0.3)
        
        # 🔥 自适应池化 - 无论输入长度如何都输出固定长度
        self.adaptive_pool = nn.AdaptiveAvgPool1d(1)
        
        # 🔥 全连接分类器
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.3),
            
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.BatchNorm1d(64),
            nn.Dropout(0.2),
            
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(0.1),
            
            nn.Linear(32, 2)  # 二分类输出
        )
        
        # 🔥 残差连接 - 帮助梯度流动
        self.residual = nn.Conv1d(1, 128, kernel_size=1)
        
    def forward(self, x):
        """
        前向传播
        
        Args:
            x: 输入张量 (batch_size, input_dim)
            
        Returns:
            输出张量 (batch_size, 2)
        """
        # 原始输入形状: (batch_size, input_dim)
        # 需要转换为1D卷积格式: (batch_size, channels=1, length=input_dim)
        x = x.unsqueeze(1)  # (batch_size, 1, input_dim)
        
        # 保存输入用于残差连接
        identity = x
        
        # 第一层卷积
        out = self.conv1(x)
        out = self.bn1(out)
        out = F.relu(out)
        out = self.dropout1(out)
        
        # 第二层卷积
        out = self.conv2(out)
        out = self.bn2(out)
        out = F.relu(out)
        out = self.dropout2(out)
        
        # 残差连接
        identity_transformed = self.residual(identity)
        out = out + identity_transformed  # 元素级相加
        
        # 第三层卷积
        out = self.conv3(out)
        out = self.bn3(out)
        out = F.relu(out)
        out = self.dropout3(out)
        
        # 自适应全局平均池化
        out = self.adaptive_pool(out)  # (batch_size, 256, 1)
        
        # 展平
        out = out.view(out.size(0), -1)  # (batch_size, 256)
        
        # 分类器
        out = self.classifier(out)
        
        return out
    
    def get_feature_maps(self, x):
        """
        获取中间特征图，用于可视化和分析
        """
        x = x.unsqueeze(1)
        
        # 第一层特征
        conv1_out = F.relu(self.bn1(self.conv1(x)))
        
        # 第二层特征
        conv2_out = F.relu(self.bn2(self.conv2(conv1_out)))
        
        # 第三层特征
        conv3_out = F.relu(self.bn3(self.conv3(conv2_out)))
        
        return {
            'conv1': conv1_out,
            'conv2': conv2_out, 
            'conv3': conv3_out
        }
