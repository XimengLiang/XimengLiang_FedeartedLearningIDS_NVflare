import matplotlib
matplotlib.use('Agg')
import matplotlib.patches as patches
import logging
from collections import Counter
from sklearn.preprocessing import MinMaxScaler
from typing import Dict
from sklearn.metrics import accuracy_score
import torch.nn.functional as F

import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
import os, subprocess
from datetime import datetime
import json
import time


import torch
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import torch.nn as nn

from nvflare.apis.shareable import Shareable
from nvflare.apis.dxo import DXO, DataKind
from nvflare.apis.fl_context import FLContext
from nvflare.app_common.aggregators.intime_accumulate_model_aggregator import InTimeAccumulateWeightedAggregator

from custom.unsw_nb15_model import IDS_MLP

class FlowerStyleAggregator(InTimeAccumulateWeightedAggregator):
    def __init__(self, expected_data_kind: str = DataKind.WEIGHTS, aggregation_weights: Dict[str, float] = None):
        super().__init__(expected_data_kind=expected_data_kind, aggregation_weights=aggregation_weights)
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.device = torch.device("cpu")
        self.logger.info("[FedAvg-SERVER] Using CPU for aggregation")
            
        self.test_path = "/Users/simonl/Downloads/FL_IDS/test_set.csv"
        self.current_round = 0
        
        self.collected_numpy_weights = {}
        
        self.fedavg_config = {
            'strategy': 'weighted_average',
            'use_dynamic_weights': True,      
            'equal_weights': False,           
            'performance_based_weights': True, 
            'min_accuracy_threshold': 0.7,  
            'weight_adjustment_factor': 0.1   
        }
        
        self.max_rounds = 10
        self.round_history = []
        self.best_accuracy = 0.0
        self.model_input_dim = None
        self.accuracy_history = []
        self.f1_history = []
        self.precision_history = []
        self.recall_history = []
        self.round_numbers = []
        
        # 🚀 新增：多客户端对比数据存储
        # self.comparison_data_path = '/Users/simonl/Downloads/multi_test/comparison_data.json'
        # self.runs_path ='/Users/simonl/Downloads/multi_test/trust_comparation_data.json'
        #--------------------------------------------------------------------------------------
        # self.runs_path ='/Users/simonl/Downloads/multi_test/experiment_rounds_data.json'
        # self.runs_path ='/Users/simonl/Downloads/multi_test/experiment_orginal_trust_data.json'
        # self.runs_path ='/Users/simonl/Downloads/multi_test/experiment_client_data.json'
        # self.runs_path ='/Users/simonl/Downloads/multi_test/experiment_noise_effect_data.json'
        self.runs_path ='/Users/simonl/Downloads/multi_test/experiment_trust2_data.json'
        self.plot_dir = '/Users/simonl/Downloads/multi_test/plots/'
        os.makedirs(self.plot_dir, exist_ok=True)
        
  
        self.current_client_count = None
        
        self.logger.info("[Init] FedAvg aggregation enabled")
        self.logger.info(f"[Init] FedAvg config: {self.fedavg_config}")

        self.use_manual_trust = True 
        self.manual_trust_mode = "replace"   
        self.manual_trust_alpha = 0.7         
        self.manual_trust_default = 1.0   
        self.exp_name = os.environ.get("FL_EXP_NAME", "set3")   
        self.manual_trust_scores = {
            "site-1": 0.4,  
            "site-2": 0.3,  
            "site-3": 1.2,  
            "site-4": 1.3,
            "site-5": 0.9}   
        # {
        #     "site-1": 1.3,  
        #     "site-2": 1.2,  
        #     "site-3": 0.4,  
        #     "site-4": 0.3,
        #     "site-5": 0.8} 
        #   
        # {
            # "site-1": 1.0,  
            # "site-2": 1.0,  
            # "site-3": 1.0,  
            # "site-4": 1.0,
            # "site-5": 1.0} 
              

        self._process_start = None         
        self._process_end = None
        self._process_start_iso = None      
        self._process_end_iso = None
        self.completion_time_sec = None



    def load_test_data(self):
        df = pd.read_csv(self.test_path)
        
        X = df.drop(columns=["label"]).values
        y = df["label"].values
        
        if self.model_input_dim is None:
            self.model_input_dim = X.shape[1]
            self.logger.info(f"[FedAvg-SERVER] Detected input dimension: {self.model_input_dim}")
        
        scaler = MinMaxScaler()
        X = scaler.fit_transform(X)
        
        X = torch.tensor(X, dtype=torch.float32)
        y = torch.tensor(y, dtype=torch.long)
        
        loader = DataLoader(TensorDataset(X, y), batch_size=128, shuffle=False)
        
        test_dist = Counter(y.numpy())
        self.logger.info(f"[FedAvg-SERVER] Test data distribution: {dict(test_dist)}")
        
        return loader, self.model_input_dim

    def accept(self, shareable: Shareable, fl_ctx: FLContext) -> bool:
        client_name = "unknown"
        try:
            peer_ctx = fl_ctx.get_prop("peer_ctx")
            if peer_ctx and "peer_name" in peer_ctx:
                client_name = peer_ctx["peer_name"]
        except Exception as e:
            self.logger.warning(f"[FedAvg-accept] Error getting client name: {str(e)}")
        
        if client_name == "unknown" or client_name == "simulator_server":
            current_count = len(self.collected_numpy_weights)
            client_name = f"site-{current_count + 1}"
        
        self.logger.info(f"[FedAvg-accept] Receiving from {client_name}")
        
        try:
            numpy_dict = None
            
            if DataKind.WEIGHTS in shareable:
                weights_data = shareable[DataKind.WEIGHTS]
                if isinstance(weights_data, dict):
                    sample_key = list(weights_data.keys())[0] if weights_data else None
                    if sample_key and isinstance(weights_data[sample_key], np.ndarray):
                        numpy_dict = weights_data
            
            elif "DXO" in shareable:
                dxo_data = shareable["DXO"]
                if isinstance(dxo_data, dict) and "data" in dxo_data:
                    data = dxo_data["data"]
                    if isinstance(data, dict):
                        sample_key = list(data.keys())[0] if data else None
                        if sample_key and isinstance(data[sample_key], np.ndarray):
                            numpy_dict = data
            
            if numpy_dict and len(numpy_dict) > 0:
                if getattr(self, "_process_start", None) is None:
                    self._process_start = time.perf_counter()
                    self._process_start_iso = datetime.now().isoformat(timespec='seconds')
                if not self.collected_numpy_weights: 
                    self._round_wallclock_start = time.perf_counter()
                if 'fc1.weight' in numpy_dict:
                    inferred_input_dim = numpy_dict['fc1.weight'].shape[1]
                    if self.model_input_dim is None:
                        self.model_input_dim = inferred_input_dim
                        self.logger.info(f"🔧 [FedAvg-accept] Inferred input dimension: {self.model_input_dim}")

                self.collected_numpy_weights[client_name] = numpy_dict
                self.logger.info(f"[FedAvg-accept]  Stored weights from {client_name}")
                
                super().accept(shareable, fl_ctx)
                return True
                    
        except Exception as e:
            self.logger.error(f"[FedAvg-accept]  Error processing {client_name}: {str(e)}")
        
        return False


    def _get_fedavg_weights(self, round_num):
        
        num_clients = len(self.collected_numpy_weights)
        client_names = list(self.collected_numpy_weights.keys())
        
        if self.current_client_count is None:
            self.current_client_count = num_clients
            self.logger.info(f"[Multi-Client] Detected {num_clients} clients for this experiment")
        
        if self.fedavg_config['equal_weights']:
            weight_per_client = 1.0 / num_clients
            weights = {name: weight_per_client for name in client_names}
            self.logger.info(f"[Round {round_num}] Using equal weights: {weights}")
            
        elif self.fedavg_config['performance_based_weights'] and len(self.round_history) > 0:

            recent_acc = self.round_history[-1]['accuracy']
            
            if recent_acc < self.fedavg_config['min_accuracy_threshold']:

                weight_per_client = 1.0 / num_clients
                weights = {name: weight_per_client for name in client_names}
                self.logger.info(f"[Round {round_num}] Low performance, using equal weights: {weights}")
            else:

                if num_clients == 3:
                    weights = {"site-1": 1, "site-2": 1, "site-3": 1}
                elif num_clients == 4:
                    weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1}
                elif num_clients == 5:
                    weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1, "site-5": 1}
                elif num_clients == 6:
                        weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1, "site-5": 1, "site-6": 1}
                elif num_clients == 9:
                        weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1, "site-5": 1, "site-6": 1, "site-7": 1, "site-8": 1, "site-9": 1}
                elif num_clients == 12:
                        weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1, "site-5": 1, "site-6": 1, "site-7": 1, "site-8": 1, "site-9": 1, "site-10": 1, "site-11": 1, "site-12": 1}
                else:

                    weight_per_client = 1.0 / num_clients
                    weights = {name: weight_per_client for name in client_names}
                

                total_weight = sum(weights.values())
                if abs(total_weight - 1.0) > 1e-6:
                    weights = {k: v/total_weight for k, v in weights.items()}
                
                self.logger.info(f"Round {round_num}] Performance-based weights: {weights}")
        else:
            if num_clients == 3:
                weights = {"site-1": 1, "site-2": 1, "site-3": 1}
            elif num_clients == 4:
                weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1}
            elif num_clients == 5:
                weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1, "site-5": 1}
            elif num_clients == 6:
                        weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1, "site-5": 1, "site-6": 1}
            elif num_clients == 9:
                        weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1, "site-5": 1, "site-6": 1, "site-7": 1, "site-8": 1, "site-9": 1}
            elif num_clients == 12:
                        weights = {"site-1": 1, "site-2": 1, "site-3": 1, "site-4": 1, "site-5": 1, "site-6": 1, "site-7": 1, "site-8": 1, "site-9": 1, "site-10": 1, "site-11": 1, "site-12": 1}
            else:
                weight_per_client = 1.0 / num_clients
                weights = {name: weight_per_client for name in client_names}
            
            self.logger.info(f"[Round {round_num}] Default FedAvg weights: {weights}")
        
        return weights

    def save_current_experiment_data(self):
        try:
            all_runs = {}
            if os.path.exists(self.runs_path):
                with open(self.runs_path, 'r') as f:
                    try:
                        all_runs = json.load(f)
                    except Exception:
                        all_runs = {}

            mean_acc = float(np.mean(self.accuracy_history)) if self.accuracy_history else 0.0
            final_acc = float(self.accuracy_history[-1]) if self.accuracy_history else 0.0

            stamp = datetime.now().isoformat(timespec='seconds')
            key = f"{self.current_client_count}C_{self.exp_name}_{stamp}"

            all_runs[key] = {
                "exp_name": self.exp_name,                 # baseline / set2 / set3
                "client_count": self.current_client_count,
                "rounds": self.round_numbers,
                "accuracy": self.accuracy_history,
                "precision": self.precision_history,
                "recall": self.recall_history,
                "f1": self.f1_history,
                "best_accuracy": self.best_accuracy,
                "mean_accuracy": mean_acc,
                "final_accuracy": final_acc,
                "timestamp": stamp,
                "trust": {
                    "mode": getattr(self, "manual_trust_mode", None),
                    "scores": getattr(self, "manual_trust_scores", None),
                    "normalized_weights_last_round": getattr(self, "last_final_weights", None)
                } ,
                "completion_time_sec": getattr(self, "completion_time_sec", None),
                "process_start_iso": getattr(self, "_process_start_iso", None),
                "process_end_iso": getattr(self, "_process_end_iso", None),
            }
            with open(self.runs_path, 'w') as f:
                json.dump(all_runs, f, indent=2)

            self.logger.info(
                f"Multi-Client] Saved run '{self.exp_name}' "
                f"({self.current_client_count} clients) to {self.runs_path} as key '{key}'"
            )

        except Exception as e:
            self.logger.error(f"[Multi-Client] Failed to save experiment data: {str(e)}")

    def _plot_final_figures(self, cm, round_num):

        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            # plt.style.use('seaborn-v0_8')
            plt.figure(figsize=(10, 6))
            acc_percent = [a * 100 for a in self.accuracy_history]
            plt.plot(self.round_numbers, acc_percent,
                    linewidth=1.8,marker='o', markersize=4,
                    label=f'{self.current_client_count} Clients Accuracy', color="#0874c1")

            plt.title(f'Accuracy Trend)', fontsize=14, fontweight='bold')
            plt.xlabel('Iterations', fontsize=12)
            plt.ylabel('Accuracy (%)', fontsize=12)
            plt.grid(True, alpha=0.3)
            plt.ylim(30, 100)
            plt.tight_layout()
            
            f_acc = os.path.join(self.plot_dir, f"final_accuracy_trend_round{round_num}_{timestamp}.png")
            plt.savefig(f_acc, dpi=300)
            plt.close()

            plt.figure(figsize=(10, 6))
            plt.plot(self.round_numbers, self.precision_history, label='Precision')
            plt.plot(self.round_numbers, self.recall_history, label='Recall')
            plt.plot(self.round_numbers, self.f1_history, label='F1-score')
            plt.title(f'Precision / Recall / F1 Trend (Round={round_num})', fontsize=14, fontweight='bold')
            plt.xlabel('Iterations', fontsize=12)
            plt.ylabel('Score', fontsize=12)
            plt.legend()
            plt.grid(True, alpha=0.3)
            plt.ylim(0.5, 1.0)
            plt.tight_layout()
            f_metrics = os.path.join(self.plot_dir, f"final_metrics_trend_round{round_num}_{timestamp}.png")
            plt.savefig(f_metrics, dpi=300)
            plt.close()

            plt.figure(figsize=(6, 5))
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False,
                        xticklabels=['Normal', 'Attack'], yticklabels=['Normal', 'Attack'])
            plt.xlabel('Predicted')
            plt.ylabel('True')
            plt.title(f'Confusion Matrix (Round {round_num})', fontsize=13)
            plt.tight_layout()
            f_cm = os.path.join(self.plot_dir, f"final_confusion_matrix_round{round_num}_{timestamp}.png")
            plt.savefig(f_cm, dpi=300)
            plt.close()
            try:
                subprocess.run(["open", f_acc])
                subprocess.run(["open", f_metrics])
                subprocess.run(["open", f_cm])
            except Exception:
                pass

            self.logger.info(f"Final plots saved:\n  - {f_acc}\n  - {f_metrics}\n  - {f_cm}")
        except Exception as e:
            self.logger.error(f"Final plotting failed: {str(e)}")



    def aggregate(self, fl_ctx: FLContext) -> Shareable:
       
        self.current_round += 1
        
        t_round = time.perf_counter()

        fl_ctx.set_prop("current_round", self.current_round)
        
        self.logger.info(f"[Round {self.current_round}] Starting FedAvg aggregation")
        self.logger.info(f"[Round {self.current_round}] Collected from: {list(self.collected_numpy_weights.keys())}")
        
        if not self.collected_numpy_weights:
            self.logger.error(f"[Round {self.current_round}] No weights collected")
            empty_dxo = DXO(data_kind=DataKind.WEIGHTS, data={})
            return empty_dxo.to_shareable()

        try:
            global_numpy_dict = None
            

            weights_strategy = self._get_fedavg_weights(self.current_round)
            
            final_weights = {}

            if self.use_manual_trust:
                mode = self.manual_trust_mode.lower()
                if mode == "replace":
                    raw = {
                        name: float(self.manual_trust_scores.get(name, self.manual_trust_default))
                        for name in self.collected_numpy_weights.keys()
                    }
                    raw = {k: max(v, 0.0) for k, v in raw.items()}
                    s = sum(raw.values())
                    if s <= 0:
                        final_weights = {k: 1.0 / len(raw) for k in raw}
                    else:
                        final_weights = {k: v / s for k, v in raw.items()}

                    self.logger.info(f"[Round {self.current_round}] REPLACE mode: "
                                    f"ignoring base weights, normalized trust -> final weights: {final_weights}")

                elif mode == "blend":
                    for name in self.collected_numpy_weights.keys():
                        base_w = float(weights_strategy.get(name, 1.0 / len(self.collected_numpy_weights)))
                        t = float(self.manual_trust_scores.get(name, self.manual_trust_default))
                        val = self.manual_trust_alpha * t + (1 - self.manual_trust_alpha) * base_w
                        final_weights[name] = max(val, 0.0)
                    s = sum(final_weights.values())
                    final_weights = {k: (v / s if s > 0 else 1.0 / len(final_weights)) for k, v in final_weights.items()}

                    self.logger.info(f"[Round {self.current_round}] BLEND mode -> final weights: {final_weights}")

                else:  # "multiply"
                    for name in self.collected_numpy_weights.keys():
                        base_w = float(weights_strategy.get(name, 1.0 / len(self.collected_numpy_weights)))
                        t = float(self.manual_trust_scores.get(name, self.manual_trust_default))
                        val = base_w * t
                        final_weights[name] = max(val, 0.0)
                    s = sum(final_weights.values())
                    final_weights = {k: (v / s if s > 0 else 1.0 / len(final_weights)) for k, v in final_weights.items()}

                    self.logger.info(f"[Round {self.current_round}]  MULTIPLY mode -> final weights: {final_weights}")
            else:
                final_weights = weights_strategy
                self.logger.info(f"[Round {self.current_round}] (No manual trust) final weights = base weights: {final_weights}")

            self.logger.info(f"[Round {self.current_round}] Base weights (for reference): {weights_strategy}")
            self.logger.info(f"[Round {self.current_round}] Manual trust: {self.manual_trust_scores}")


            for client_name, client_numpy_dict in self.collected_numpy_weights.items():
                # weight = weights_strategy.get(client_name, 1.0 / len(self.collected_numpy_weights))
                weight = final_weights.get(client_name, 1.0 / len(self.collected_numpy_weights))

                self.logger.info(f"[Round {self.current_round}] Processing {client_name} with weight {weight:.3f}")
                
                if global_numpy_dict is None:
                    global_numpy_dict = {}
                    for key, value in client_numpy_dict.items():
                        global_numpy_dict[key] = value * weight
                else:
                    for key in global_numpy_dict.keys():
                        if key in client_numpy_dict:
                            global_numpy_dict[key] += client_numpy_dict[key] * weight
            
            if global_numpy_dict:
                self.logger.info(f"Round {self.current_round}] FedAvg aggregation completed")
                self.logger.info(f"Round {self.current_round}] Aggregated {len(global_numpy_dict)} weight tensors")
                try:
                    test_loader, input_dim = self.load_test_data()
                    
                    if self.model_input_dim is not None:
                        input_dim = self.model_input_dim
                    
                    if global_numpy_dict and 'layers.0.weight' in global_numpy_dict:
                        actual_input_dim = global_numpy_dict['layers.0.weight'].shape[1]
                        self.logger.info(f"Detected actual input dim from weights: {actual_input_dim}")
                        model = IDS_MLP(input_dim=actual_input_dim).to(self.device)
                    elif self.model_input_dim is not None:
                        model = IDS_MLP(input_dim=self.model_input_dim).to(self.device)
                    else:
                        model = IDS_MLP(input_dim=input_dim).to(self.device)
                
                    state_dict = {}
                    for key, numpy_value in global_numpy_dict.items():
                        state_dict[key] = torch.tensor(numpy_value)
                    model.load_state_dict(state_dict)
                    
                    acc, loss, f1, is_learning,cm = self.evaluate_model(model, test_loader, self.current_round)

                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    save_path = f"/tmp/fedavg_global_model_round_{self.current_round}_{timestamp}.pt"
                    torch.save(model.state_dict(), save_path)
                    self.logger.info(f"[Round {self.current_round}] Saved FedAvg global model to: {save_path}")
                    
                except Exception as eval_error:
                    self.logger.error(f"[Round {self.current_round}] Evaluation failed: {str(eval_error)}")

                self.collected_numpy_weights.clear()
                
                result_dxo = DXO(data_kind=DataKind.WEIGHTS, data=global_numpy_dict)
                result_dxo.set_meta_prop("data_type", "numpy_dict")
                result_dxo.set_meta_prop("round", self.current_round)
                result_dxo.set_meta_prop("current_round", self.current_round)
                result_dxo.set_meta_prop("aggregation_strategy", "fedavg_weighted_average")
                result_dxo.set_meta_prop("input_dim", self.model_input_dim)
                result_dxo.set_meta_prop("fedavg_enabled", True)
                
                if self.current_round == self.max_rounds:
                    self._process_end = time.perf_counter()
                    if self._process_start is not None:
                        self.completion_time_sec = self._process_end - self._process_start
                        self.completion_time_sec = (self.cumulative_total_time[-1]
                                                    if getattr(self, "cumulative_total_time", None) else None)
                    
                    if self.completion_time_sec is not None:
                        msg = (f"[Clock] COMPLETION TIME over {self.current_round} rounds: "
                            f"{self.completion_time_sec:.2f}s ({self.completion_time_sec/60:.2f} min)")
                        self.logger.info(msg)
                    
                    try:
                        self._plot_final_figures(cm=cm, round_num=self.current_round)
                        self.save_current_experiment_data()
                        # self.plot_multi_client_comparison()
                    except Exception as e:
                            self.logger.error(f"Final-round post actions failed: {str(e)}")
                
                return result_dxo.to_shareable()
            
            else:
                self.logger.error(f"[Round {self.current_round}] Failed to create global numpy dict")
                
        except Exception as e:
            self.logger.error(f"[Round {self.current_round}] FedAvg aggregation failed: {str(e)}")
        
        self.collected_numpy_weights.clear()
        empty_dxo = DXO(data_kind=DataKind.WEIGHTS, data={})
        return empty_dxo.to_shareable()

    def evaluate_model(self, model, test_loader, round_num):
        model.eval()
        correct = 0
        total = 0
        all_preds = []
        all_labels = []
        total_loss = 0.0
        
        criterion = nn.CrossEntropyLoss()

        with torch.no_grad():
            for batch_x, batch_y in test_loader:
                batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                outputs = model(batch_x)
                loss = criterion(outputs, batch_y)
                total_loss += loss.item()
                
                _, predicted = torch.max(outputs, 1)
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(batch_y.cpu().numpy())
                correct += (predicted == batch_y).sum().item()
                total += batch_y.size(0)

        acc = correct / total
        avg_loss = total_loss / len(test_loader)

        f1 = f1_score(all_labels, all_preds, average='binary')
        precision = precision_score(all_labels, all_preds, average='binary')
        recall = recall_score(all_labels, all_preds, average='binary')
        cm = confusion_matrix(all_labels, all_preds)

        self.accuracy_history.append(acc)
        self.f1_history.append(f1)
        self.precision_history.append(precision)
        self.recall_history.append(recall)
        self.round_numbers.append(round_num)

      
        max_rounds = 5  
        # if round_num >= max_rounds:
        #     try:
        #         self.logger.info("[Multi-Client] Experiment completed, saving data...")
        #         self.save_current_experiment_data()
        #         self.plot_multi_client_comparison()
                
        #     except Exception as e:
        #         self.logger.error(f"[Multi-Client] Failed to save/plot comparison data: {str(e)}")

        # if round_num >= 10:  
        #     try:
        #         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        #         plt.style.use('seaborn-v0_8')
        #         plt.figure(figsize=(10, 6))
        #         plt.plot(self.round_numbers, [a*100 for a in self.accuracy_history], 
        #                 linewidth=1.5, markersize=4, label=f'{self.current_client_count} Clients Accuracy', color="#0874c1")
        #         plt.title(f'Accuracy Trend ({self.current_client_count} Clients)', fontsize=14, fontweight='bold')
        #         plt.xlabel('Iterations', fontsize=12)
        #         plt.ylabel('Accuracy (%)', fontsize=12)
        #         plt.grid(True, alpha=0.3)
        #         plt.ylim(30, 100)
        #         plt.tight_layout()
        #         filepath_current = os.path.join(self.plot_dir, f"current_{self.current_client_count}clients_accuracy_{timestamp}.png")
        #         plt.savefig(filepath_current, dpi=300)
        #         plt.close()
        #         plt.figure(figsize=(10, 6))
        #         plt.plot(self.round_numbers, self.precision_history, label='Precision', marker='s')
        #         plt.plot(self.round_numbers, self.recall_history, label='Recall', marker='^')
        #         plt.plot(self.round_numbers, self.f1_history, label='F1-score', marker='o')
        #         plt.title(f'FedAvg Performance Metrics ({self.current_client_count} Clients)', fontsize=14, fontweight='bold')
        #         plt.xlabel('Iterations', fontsize=12)
        #         plt.ylabel('Score', fontsize=12)
        #         plt.legend()
        #         plt.grid(True, alpha=0.3)
        #         plt.ylim(0.5, 1.0)
        #         plt.tight_layout()
        #         filepath_metrics = os.path.join(self.plot_dir, f"current_{self.current_client_count}clients_metrics_{timestamp}.png")
        #         plt.savefig(filepath_metrics, dpi=300)
        #         plt.close()

        #         self.logger.info(f"[FedAvg] Current experiment plots saved")

        #     except Exception as e:
        #         self.logger.error(f"[FedAvg] Current plot generation failed: {str(e)}")

        is_learning = len(set(all_preds)) > 1
        
        pred_dist = Counter(all_preds)
        true_dist = Counter(all_labels)
        
        self.logger.info(f"\n ========== Round {round_num} FedAvg Global Model Evaluation ==========")
        self.logger.info(f"[FedAvg-SERVER] Global Model Accuracy: {acc * 100:.2f}%")
        self.logger.info(f"[FedAvg-SERVER] Loss: {avg_loss:.4f}")
        self.logger.info(f"[FedAvg-SERVER] Precision: {precision:.3f}, Recall: {recall:.3f}, F1: {f1:.3f}")
        self.logger.info(f"Predicted: {pred_dist}, True: {true_dist}")
        self.logger.info(f"Learning Status: {'Learning' if is_learning else 'Not Learning'}")
        self.logger.info(f" [Multi-Client] Current experiment: {self.current_client_count} clients")
        

        self.round_history.append({
            'round': round_num,
            'accuracy': acc,
            'loss': avg_loss,
            'f1': f1,
            'is_learning': is_learning,
            'precision': precision,
            'recall': recall
        })
        
        if round_num > 1:
            prev_acc = self.round_history[-2]['accuracy']
            acc_change = acc - prev_acc
            trend = "Improving" if acc_change > 0.01 else "Declining" if acc_change < -0.01 else "Stable"
            self.logger.info(f"[FedAvg] Trend: {trend} (Δ={acc_change*100:+.2f}%)")
        
        if acc > self.best_accuracy:
            self.best_accuracy = acc
            improvement = acc - (self.round_history[-2]['accuracy'] if len(self.round_history) > 1 else 0)
            self.logger.info(f"[FedAvg] New best accuracy: {acc * 100:.2f}% (+{improvement*100:.2f}%)")
        
        self.logger.info(f"============================================================\n")

        return acc, avg_loss, f1, is_learning, cm