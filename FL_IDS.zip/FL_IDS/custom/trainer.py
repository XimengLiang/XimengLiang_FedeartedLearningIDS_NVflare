import logging
from collections import Counter, OrderedDict
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import math
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from imblearn.over_sampling import SMOTE
from collections import Counter

from nvflare.apis.executor import Executor
from nvflare.apis.shareable import Shareable
from nvflare.apis.dxo import DXO, DataKind
from nvflare.apis.fl_context import FLContext
from nvflare.apis.signal import Signal

import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import torch.nn.functional as F

from custom.unsw_nb15_model import IDS_MLP
from custom.unsw_nb15_model import IDS_CNN

class FocalLoss(nn.Module):
    def __init__(self, alpha=1, gamma=2, weight=None, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.weight = weight
        self.reduction = reduction

    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, weight=self.weight, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss

class CustomTrainer(Executor):
    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)

        self.device = torch.device("cpu")
        self.logger.info("[FedAvg] Using CPU for standard federated learning")

        self.train_path = None
        self.test_path = None
        self.scaler = None

        self.fedavg_config = {
            'strategy': 'standard_fedavg',
            'local_epochs': 10,           
            'batch_size': 64,            
            'learning_rate': 0.001,      
            'weight_decay': 0.001,       
            'use_scheduler': True,       
            'early_stopping': True,      
            'patience': 3               
        }
        
        self.logger.info(f"[Init] FedAvg enabled with config: {self.fedavg_config}")
        
    def _set_client_paths(self, client_name):
        if client_name == "site-1":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site1_noisy.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-2":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site2_noisy.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-3":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site3_noisy.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-4":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site4_noisy.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-5":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site5_noisy.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-6":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site6_average.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-7":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site7_average.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-8":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site8_average.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-9":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site9_average.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-10":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site10_average.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-11":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site11_average.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        elif client_name == "site-12":
            self.train_path = "/Users/simonl/Downloads/multi_test/train_site12_average.csv"
            self.test_path = "/Users/simonl/Downloads/multi_test/test_set.csv"
        else:
            raise ValueError(f"Unsupported client name: {client_name}")

    def get_weights_as_dict(self, model):
        state_dict = model.state_dict()
        numpy_dict = {}
        for key, value in state_dict.items():
            numpy_dict[key] = value.cpu().numpy()
        
        self.logger.info(f"[FedAvg] Converted model to numpy dict with {len(numpy_dict)} keys")
        return numpy_dict

    def set_weights_from_dict(self, model, numpy_dict):
        if numpy_dict is None or len(numpy_dict) == 0:
            self.logger.warning("[FedAvg] No weights to set")
            return False
            
        try:
            state_dict = {}
            for key, numpy_value in numpy_dict.items():
                state_dict[key] = torch.tensor(numpy_value)
            
            model.load_state_dict(state_dict, strict=True)
            self.logger.info(f"[FedAvg] Successfully set weights from numpy dict with {len(numpy_dict)} keys")
            return True
            
        except Exception as e:
            self.logger.error(f"[FedAvg] Failed to set weights: {str(e)}")
            return False

    def load_data(self):
        train_df = pd.read_csv(self.train_path)
        test_df = pd.read_csv(self.test_path)

        train_dist = train_df["label"].value_counts().sort_index()
        test_dist = test_df["label"].value_counts().sort_index()
        self.logger.info(f"[FedAvg] Training data distribution: {dict(train_dist)}")
        self.logger.info(f"[FedAvg] Test data distribution: {dict(test_dist)}")

        X_train = train_df.drop(columns=["label"]).values
        y_train = train_df["label"].values
        X_test = test_df.drop(columns=["label"]).values
        y_test = test_df["label"].values

        self.scaler = MinMaxScaler()
        X_train = self.scaler.fit_transform(X_train)
        X_test = self.scaler.transform(X_test)
        
        self.logger.info(f"[FedAvg] Feature count: {X_train.shape[1]}")
        self.logger.info(f"[FedAvg] Training samples: {len(X_train)}")

        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.long)
        X_test = torch.tensor(X_test, dtype=torch.float32)
        y_test = torch.tensor(y_test, dtype=torch.long)

        train_loader = DataLoader(
            TensorDataset(X_train, y_train), 
            batch_size=self.fedavg_config['batch_size'],
            shuffle=True, 
            drop_last=True,
            num_workers=0,
            pin_memory=False
        )
        
        test_loader = DataLoader(
            TensorDataset(X_test, y_test),
            batch_size=128,
            shuffle=False,
            num_workers=0,
            pin_memory=False
        )

        return train_loader, test_loader, X_train.shape[1]

    def get_class_weights(self, train_loader):
        labels = []
        for _, y in train_loader:
            labels.extend(y.numpy())
        
        class_counts = Counter(labels)
        total = sum(class_counts.values())
        
        n_classes = len(class_counts)
        balanced_weights = []
        
        for i in range(n_classes):
            if i in class_counts:
                weight = total / (n_classes * class_counts[i])
                weight = min(weight, 3.0)
                balanced_weights.append(weight)
            else:
                balanced_weights.append(1.0)
        
        weights = torch.tensor(balanced_weights, dtype=torch.float32)
        self.logger.info(f"[FedAvg] Class weights: {weights.numpy()}")
        
        return weights

    def evaluate_model(self, model, test_loader, silent=False):
        model.eval()
        correct = 0
        total = 0
        all_preds = []
        all_labels = []
        total_loss = 0.0
        criterion = nn.CrossEntropyLoss()

        with torch.no_grad():
            for batch_x, batch_y in test_loader:
                batch_x = batch_x.to(self.device)
                batch_y = batch_y.to(self.device)
                outputs = model(batch_x)
                loss = criterion(outputs, batch_y)
                total_loss += loss.item()
                
                _, predicted = torch.max(outputs, 1)
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(batch_y.cpu().numpy())
                correct += (predicted == batch_y).sum().item()
                total += batch_y.size(0)

        acc = correct / total
        avg_loss = total_loss / len(test_loader)

        if not silent:
            pred_dist = Counter(all_preds)
            true_dist = Counter(all_labels)
            self.logger.info(f"[FedAvg] Test Accuracy: {acc * 100:.2f}% | Loss: {avg_loss:.4f}")
            self.logger.info(f"[FedAvg] Predicted: {pred_dist}, True: {true_dist}")

            cm = confusion_matrix(all_labels, all_preds)
            tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
            
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
            
            self.logger.info(f"[FedAvg] Precision: {precision:.3f}, Recall: {recall:.3f}, F1: {f1:.3f}")

        return acc, avg_loss

    def train_model(self, model, initial_numpy_dict=None, print_prefix="", round_num=1):

        import time
        seed = int(time.time()) % 10000
        torch.manual_seed(seed)
        np.random.seed(seed)
        
        self.logger.info(f"{print_prefix}[FedAvg] Using random seed: {seed}")

        train_loader, test_loader, input_dim = self.load_data()
        
        self.logger.info(f"{print_prefix}[FedAvg] Standard FedAvg training (round {round_num})")
        
        # 加载初始权重
        if initial_numpy_dict is not None:
            if self.set_weights_from_dict(model, initial_numpy_dict):
                self.logger.info(f"{print_prefix}[FedAvg] Loaded initial weights from global model")
                init_acc, init_loss = self.evaluate_model(model, test_loader, silent=True)
                self.logger.info(f"{print_prefix}🔍 [FedAvg] Initial model performance: Acc={init_acc*100:.2f}%, Loss={init_loss:.4f}")
            else:
                self.logger.warning(f"{print_prefix}[FedAvg] Failed to load initial weights, using random")
        else:
            self.logger.info(f"{print_prefix}[FedAvg] Using random initialization")

        class_weights = self.get_class_weights(train_loader).to(self.device)

        use_focal_loss = True
        if use_focal_loss:
            criterion = FocalLoss(alpha=1.0, gamma=2.0, weight=class_weights)
            self.logger.info(f"{print_prefix}[FedAvg] Using Focal Loss")
        else:
            criterion = nn.CrossEntropyLoss(weight=class_weights)
            self.logger.info(f"{print_prefix}[FedAvg] Using CrossEntropy Loss")
        
        optimizer = optim.Adam(
            model.parameters(), 
            lr=self.fedavg_config['learning_rate'],
            weight_decay=self.fedavg_config['weight_decay']
        )
        
        if self.fedavg_config['use_scheduler']:
            scheduler = optim.lr_scheduler.CosineAnnealingLR(
                optimizer, 
                T_max=self.fedavg_config['local_epochs'],
                eta_min=1e-6
            )
        
        self.logger.info(f"{print_prefix}[FedAvg] Starting standard federated training:")
        
        best_acc = 0.0
        patience_counter = 0
        max_patience = self.fedavg_config['patience'] if self.fedavg_config['early_stopping'] else float('inf')
        
        for epoch in range(self.fedavg_config['local_epochs']):
            model.train()
            total_loss = 0.0
            num_batches = 0
            
            for batch_x, batch_y in train_loader:
                batch_x = batch_x.to(self.device, dtype=torch.float32)
                batch_y = batch_y.to(self.device, dtype=torch.long)
                
                optimizer.zero_grad()
                
                output = model(batch_x)
                loss = criterion(output, batch_y)  #
                
                loss.backward()
                
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                
                optimizer.step()
                total_loss += loss.item()
                num_batches += 1

            avg_loss = total_loss / num_batches
            acc, val_loss = self.evaluate_model(model, test_loader, silent=True)
            
            if self.fedavg_config['use_scheduler']:
                old_lr = optimizer.param_groups[0]['lr']
                scheduler.step()
                current_lr = optimizer.param_groups[0]['lr']
            else:
                current_lr = optimizer.param_groups[0]['lr']


            self.logger.info(f"{print_prefix}[Epoch {epoch + 1}] Loss: {avg_loss:.4f} | Val Loss: {val_loss:.4f} | Accuracy: {acc * 100:.2f}% | LR: {current_lr:.6f}")
            

            if self.fedavg_config['early_stopping']:
                if acc > best_acc:
                    best_acc = acc
                    patience_counter = 0
                else:
                    patience_counter += 1
                    
                if patience_counter >= max_patience:
                    self.logger.info(f"{print_prefix}[FedAvg] Early stopping at epoch {epoch + 1}")
                    break

        final_acc, final_loss = self.evaluate_model(model, test_loader, silent=False)
        self.logger.info(f"{print_prefix}[FedAvg] Training completed. Final Accuracy: {final_acc * 100:.2f}%")

        return self.get_weights_as_dict(model)

    def execute(self, task_name: str, shareable: Shareable, fl_ctx: FLContext, abort_signal: Signal) -> Shareable:
        if abort_signal.triggered:
            self.logger.warning("[FedAvg] Training aborted by server.")
            return shareable

        client_name = fl_ctx.get_identity_name()
        self._set_client_paths(client_name)
        prefix = f"[{client_name}] "


        current_round = fl_ctx.get_prop("current_round", 1)
        self.logger.info(f"{prefix}[FedAvg] Starting standard federated training for task '{task_name}' - Round {current_round}")

        initial_numpy_dict = None
        
        try:
            if DataKind.WEIGHTS in shareable:
                weights_data = shareable[DataKind.WEIGHTS]
                if isinstance(weights_data, dict):
                    sample_key = list(weights_data.keys())[0] if weights_data else None
                    if sample_key and isinstance(weights_data[sample_key], np.ndarray):
                        initial_numpy_dict = weights_data
                        self.logger.info(f"{prefix}[FedAvg] Got initial weights from server")
            
            elif "DXO" in shareable:
                dxo_data = shareable["DXO"]
                if isinstance(dxo_data, dict) and "data" in dxo_data:
                    data = dxo_data["data"]
                    if isinstance(data, dict):
                        sample_key = list(data.keys())[0] if data else None
                        if sample_key and isinstance(data[sample_key], np.ndarray):
                            initial_numpy_dict = data
                            self.logger.info(f"{prefix}[FedAvg] Got initial weights from DXO")
            
            if initial_numpy_dict is None:
                self.logger.warning(f"{prefix}[FedAvg] No initial weights found, using random initialization")
            
        except Exception as e:
            self.logger.error(f"{prefix}[FedAvg] Error extracting weights: {str(e)}")
            initial_numpy_dict = None


        _, _, input_dim = self.load_data()

        if initial_numpy_dict and 'layers.0.weight' in initial_numpy_dict:
            actual_input_dim = initial_numpy_dict['layers.0.weight'].shape[1]
            self.logger.info(f"{prefix}[FedAvg] Using input_dim from weights: {actual_input_dim}")
            input_dim = actual_input_dim

        try:
            model = IDS_MLP(input_dim=input_dim, dropout_rate=0.2).to(self.device)
            self.logger.info(f"{prefix}[FedAvg] Created IDS_MLP with input_dim={input_dim}")
        except TypeError:
            try:
                model = IDS_MLP(input_dim=input_dim).to(self.device)
                self.logger.info(f"{prefix}[FedAvg] Created IDS_MLP with input_dim={input_dim} (fallback)")
            except Exception as e2:
                self.logger.error(f"{prefix}[FedAvg] Failed to create model: {str(e2)}")
                return Shareable()
                

        trained_numpy_dict = self.train_model(model, initial_numpy_dict, prefix, current_round)

        try:
            result_dxo = DXO(data_kind=DataKind.WEIGHTS, data=trained_numpy_dict)
            result_dxo.set_meta_prop("NUM_STEPS_CURRENT_ROUND", self.fedavg_config['local_epochs'])
            result_dxo.set_meta_prop("client_name", client_name)
            result_dxo.set_meta_prop("data_type", "numpy_dict")
            result_dxo.set_meta_prop("round_num", current_round)
            result_dxo.set_meta_prop("fedavg_enabled", True)  
            result_dxo.set_meta_prop("strategy", "standard_fedavg")
            
            result_shareable = result_dxo.to_shareable()
            self.logger.info(f"{prefix}[FedAvg] Successfully created result shareable")
            
            return result_shareable
            
        except Exception as e:
            self.logger.error(f"{prefix}[FedAvg] Error creating result shareable: {str(e)}")
            return Shareable()